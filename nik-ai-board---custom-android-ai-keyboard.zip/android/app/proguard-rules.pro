# ProGuard rules for NIK-Ai board (IME + Gemini SDK + Gson)
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keep class com.nikai.board.** { *; }
-keep class com.google.gson.** { *; }
-dontwarn com.google.ai.client.generativeai.**
