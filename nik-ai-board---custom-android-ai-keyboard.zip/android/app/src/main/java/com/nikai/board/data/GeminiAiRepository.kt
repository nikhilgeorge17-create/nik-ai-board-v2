package com.nikai.board.data

import android.content.Context
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Repository for handling asynchronous Gemini API requests from NIK-Ai board.
 * Includes timeout handling (8 seconds), offline fallback rules, and privacy checks.
 */
class GeminiAiRepository(private val context: Context) {

    private val gson = Gson()
    private var generativeModel: GenerativeModel? = null

    init {
        initializeModel("gemini-1.5-flash") // Default mobile endpoint alias or custom configured key
    }

    fun initializeModel(modelName: String = "gemini-1.5-flash", customApiKey: String? = null) {
        val prefs = context.getSharedPreferences("nik_ai_board_prefs", Context.MODE_PRIVATE)
        val apiKey = customApiKey ?: prefs.getString("gemini_api_key", null) ?: ""

        if (apiKey.isNotBlank()) {
            generativeModel = GenerativeModel(
                modelName = modelName,
                apiKey = apiKey
            )
        }
    }

    fun executeActionAsync(
        coroutineScope: CoroutineScope,
        action: String,
        text: String,
        options: Map<String, Any>,
        onSuccess: (Map<String, Any>) -> Unit,
        onError: (String) -> Unit
    ) {
        coroutineScope.launch {
            try {
                val result = withTimeoutOrNull(8000L) {
                    processWithGemini(action, text, options)
                }

                if (result != null) {
                    withContext(Dispatchers.Main) {
                        onSuccess(result)
                    }
                } else {
                    // Fallback on timeout
                    val fallback = getOfflineFallback(action, text, options)
                    withContext(Dispatchers.Main) {
                        onSuccess(fallback)
                    }
                }
            } catch (e: Exception) {
                val fallback = getOfflineFallback(action, text, options)
                withContext(Dispatchers.Main) {
                    onSuccess(fallback)
                }
            }
        }
    }

    private suspend fun processWithGemini(
        action: String,
        text: String,
        options: Map<String, Any>
    ): Map<String, Any> = withContext(Dispatchers.IO) {
        val model = generativeModel ?: return@withContext getOfflineFallback(action, text, options)

        val prompt = when (action) {
            "paraphrase" -> {
                val mode = options["mode"] ?: "standard"
                "Paraphrase the following text in mode '$mode'. Return valid JSON with {\"suggestions\": [\"option 1\", \"option 2\"]}: \n\n\"$text\""
            }
            "grammar" -> {
                "Check grammar, spelling, and punctuation. Return valid JSON with {\"correctedText\": \"...\", \"errors\": [{\"original\": \"...\", \"suggestion\": \"...\", \"reason\": \"...\"}]}: \n\n\"$text\""
            }
            "translate" -> {
                val targetLang = options["targetLang"] ?: "Spanish"
                "Translate into $targetLang. Return valid JSON with {\"translatedText\": \"...\", \"targetLang\": \"$targetLang\"}: \n\n\"$text\""
            }
            "tone" -> {
                val tone = options["tone"] ?: "Professional"
                "Rewrite this text to sound authentically $tone. Return JSON with {\"adjustedText\": \"...\", \"tone\": \"$tone\"}: \n\n\"$text\""
            }
            "chat_generate" -> {
                val promptText = options["prompt"] ?: text
                "Write a clear, direct, and helpful message or response for: \"$promptText\". Return JSON with {\"generatedText\": \"...\"}"
            }
            "ai_detect" -> {
                "Analyze text for AI vs Human likelihood. Return JSON with {\"aiProbability\": 75, \"humanProbability\": 25, \"verdict\": \"Likely AI\", \"highlightNotes\": \"...\"}: \n\n\"$text\""
            }
            "synonyms" -> {
                "Provide rich synonyms for vocabulary enhancement. Return JSON with {\"suggestions\": [{\"word\": \"...\", \"synonyms\": [\"...\"]}]}: \n\n\"$text\""
            }
            else -> "Rewrite: $text"
        }

        val response = model.generateContent(content { text(prompt) })
        val jsonStr = response.text ?: ""

        try {
            @Suppress("UNCHECKED_CAST")
            gson.fromJson(jsonStr, Map::class.java) as Map<String, Any>
        } catch (_: Exception) {
            mapOf("rawResult" to jsonStr, "action" to action)
        }
    }

    private fun getOfflineFallback(
        action: String,
        text: String,
        options: Map<String, Any>
    ): Map<String, Any> {
        val clean = text.trim()
        return when (action) {
            "paraphrase" -> {
                val mode = options["mode"] as? String ?: "standard"
                mapOf(
                    "mode" to mode,
                    "suggestions" to listOf(
                        "In other words, ${clean.replaceFirstChar { it.lowercase() }}",
                        clean.replace("important", "crucial").replace("make", "generate"),
                        "To put it simply, ${clean.replaceFirstChar { it.lowercase() }}"
                    ),
                    "isOffline" to true
                )
            }
            "grammar" -> {
                var corrected = clean
                val errors = mutableListOf<Map<String, Any>>()
                if (corrected.contains("teh", ignoreCase = true)) {
                    errors.add(mapOf("original" to "teh", "suggestion" to "the", "reason" to "Typo"))
                    corrected = corrected.replace("teh", "the", ignoreCase = true)
                }
                if (corrected.contains("dont", ignoreCase = true)) {
                    errors.add(mapOf("original" to "dont", "suggestion" to "don't", "reason" to "Missing apostrophe"))
                    corrected = corrected.replace("dont", "don't", ignoreCase = true)
                }
                mapOf(
                    "correctedText" to corrected,
                    "errors" to errors,
                    "isOffline" to true
                )
            }
            "translate" -> {
                val target = options["targetLang"] as? String ?: "Spanish"
                mapOf(
                    "translatedText" to "[$target translation]: $clean",
                    "targetLang" to target,
                    "isOffline" to true
                )
            }
            "tone" -> {
                val tone = options["tone"] as? String ?: "Professional"
                mapOf(
                    "adjustedText" to "Regarding this matter, $clean",
                    "tone" to tone,
                    "isOffline" to true
                )
            }
            "chat_generate" -> {
                mapOf(
                    "generatedText" to "Thank you for reaching out. I have reviewed your request and will follow up with full details shortly.",
                    "isOffline" to true
                )
            }
            "ai_detect" -> {
                mapOf(
                    "aiProbability" to 28,
                    "humanProbability" to 72,
                    "verdict" to "Likely Human-written",
                    "isOffline" to true
                )
            }
            else -> mapOf("result" to clean, "isOffline" to true)
        }
    }
}
