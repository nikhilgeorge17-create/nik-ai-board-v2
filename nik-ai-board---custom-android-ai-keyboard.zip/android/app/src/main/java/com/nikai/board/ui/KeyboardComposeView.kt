package com.nikai.board.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nikai.board.AiResultUiState

enum class KeyboardLayoutMode {
    ALPHA_LOWER,
    ALPHA_UPPER,
    NUMERIC,
    SYMBOLS
}

/**
 * Modern Jetpack Compose QWERTY keyboard view with integrated AI Toolbar,
 * inline AI suggestion sheet, smart chat drawer, and system keyboard switcher.
 */
@Composable
fun KeyboardComposeView(
    isSensitiveField: Boolean,
    aiUiState: AiResultUiState,
    onKeyPress: (String) -> Unit,
    onDelete: () -> Unit,
    onSpace: () -> Unit,
    onEnter: () -> Unit,
    onSwitchKeyboard: () -> Unit,
    onAiAction: (String, Map<String, Any>) -> Unit,
    onClearAiResult: () -> Unit,
    onInsertText: (String) -> Unit,
    onReplaceSelection: (String) -> Unit
) {
    var layoutMode by remember { mutableStateOf(KeyboardLayoutMode.ALPHA_LOWER) }
    var isDrawerOpen by remember { mutableStateOf(false) }
    var activeAiTool by remember { mutableStateOf<String?>(null) }

    val keyboardBg = Color(0xFF0F172A)
    val keyBg = Color(0xFF1E293B)
    val keyActiveBg = Color(0xFF334155)
    val accentColor = Color(0xFF10B981)
    val textColor = Color(0xFFF8FAFC)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(keyboardBg)
            .navigationBarsPadding()
            .padding(horizontal = 4.dp, vertical = 6.dp)
    ) {
        // Top AI Toolbar directly above keys
        AiToolbar(
            isSensitiveField = isSensitiveField,
            activeTool = activeAiTool,
            onToolSelected = { tool ->
                if (tool == "chat") {
                    isDrawerOpen = !isDrawerOpen
                    activeAiTool = if (isDrawerOpen) "chat" else null
                } else {
                    isDrawerOpen = false
                    activeAiTool = tool
                    val options: Map<String, Any> = when (tool) {
                        "paraphrase" -> mapOf("mode" to "standard")
                        "translate" -> mapOf("targetLang" to "Malayalam")
                        "tone" -> mapOf("tone" to "Professional")
                        else -> emptyMap()
                    }
                    val actionKey = if (tool == "detector") "ai_detect" else tool
                    onAiAction(actionKey, options)
                }
            },
            onExecuteAi = onAiAction
        )

        // Live Inline AI Result Strip (Paraphrase / Grammar / Translate / Tone / Detector)
        if (!isSensitiveField && (aiUiState.isLoading || aiUiState.suggestions.isNotEmpty() || aiUiState.badgeText != null || aiUiState.errorMessage != null)) {
            Spacer(modifier = Modifier.height(4.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131D31), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when {
                            aiUiState.isLoading -> "✨ NIK-Ai processing..."
                            aiUiState.isOffline -> "✨ Offline Fallback Result"
                            else -> "✨ NIK-Ai Suggestion (tap to replace)"
                        },
                        color = accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier
                            .size(16.dp)
                            .clickable {
                                activeAiTool = null
                                onClearAiResult()
                            }
                    )
                }

                if (aiUiState.errorMessage != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = aiUiState.errorMessage, color = Color(0xFFFBBF24), fontSize = 12.sp)
                }

                if (aiUiState.badgeText != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = aiUiState.badgeText, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                if (aiUiState.suggestions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(aiUiState.suggestions) { suggestion ->
                            Box(
                                modifier = Modifier
                                    .widthIn(max = 260.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(keyBg)
                                    .clickable {
                                        onReplaceSelection(suggestion)
                                        activeAiTool = null
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = suggestion,
                                    color = textColor,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Expandable Smart AI Drawer
        AnimatedVisibility(
            visible = isDrawerOpen,
            enter = slideInVertically(initialOffsetY = { -it }),
            exit = slideOutVertically(targetOffsetY = { -it })
        ) {
            AiDrawer(
                generatedPreview = if (aiUiState.activeAction == "chat_generate") aiUiState.primaryResult else null,
                isLoading = aiUiState.isLoading && aiUiState.activeAction == "chat_generate",
                onSubmitPrompt = { prompt ->
                    onAiAction("chat_generate", mapOf("prompt" to prompt))
                },
                onClose = {
                    isDrawerOpen = false
                    activeAiTool = null
                },
                onInsertGenerated = { generatedText ->
                    onInsertText(generatedText)
                    isDrawerOpen = false
                    activeAiTool = null
                }
            )
        }

        // QWERTY Rows
        when (layoutMode) {
            KeyboardLayoutMode.ALPHA_LOWER, KeyboardLayoutMode.ALPHA_UPPER -> {
                val isUpper = layoutMode == KeyboardLayoutMode.ALPHA_UPPER
                val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
                val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
                val row3 = listOf("z", "x", "c", "v", "b", "n", "m")

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row1.forEach { char ->
                        val displayChar = if (isUpper) char.uppercase() else char
                        KeyButton(
                            modifier = Modifier.weight(1f),
                            label = displayChar,
                            keyBg = keyBg,
                            textColor = textColor,
                            onClick = {
                                onKeyPress(displayChar)
                                if (isUpper) layoutMode = KeyboardLayoutMode.ALPHA_LOWER
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    row2.forEach { char ->
                        val displayChar = if (isUpper) char.uppercase() else char
                        KeyButton(
                            modifier = Modifier.weight(1f),
                            label = displayChar,
                            keyBg = keyBg,
                            textColor = textColor,
                            onClick = {
                                onKeyPress(displayChar)
                                if (isUpper) layoutMode = KeyboardLayoutMode.ALPHA_LOWER
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButtonKey(
                        modifier = Modifier.weight(1.5f),
                        icon = Icons.Default.KeyboardArrowUp,
                        isActive = isUpper,
                        activeBg = accentColor,
                        keyBg = keyActiveBg,
                        onClick = {
                            layoutMode = if (isUpper) KeyboardLayoutMode.ALPHA_LOWER else KeyboardLayoutMode.ALPHA_UPPER
                        }
                    )

                    row3.forEach { char ->
                        val displayChar = if (isUpper) char.uppercase() else char
                        KeyButton(
                            modifier = Modifier.weight(1f),
                            label = displayChar,
                            keyBg = keyBg,
                            textColor = textColor,
                            onClick = {
                                onKeyPress(displayChar)
                                if (isUpper) layoutMode = KeyboardLayoutMode.ALPHA_LOWER
                            }
                        )
                    }

                    IconButtonKey(
                        modifier = Modifier.weight(1.5f),
                        icon = Icons.Default.Backspace,
                        isActive = false,
                        activeBg = accentColor,
                        keyBg = keyActiveBg,
                        onClick = onDelete
                    )
                }
            }

            KeyboardLayoutMode.NUMERIC -> {
                val numRow1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
                val numRow2 = listOf("@", "#", "$", "%", "&", "-", "+", "(", ")")
                val numRow3 = listOf("*", "\"", "'", ":", ";", "!", "?")

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    numRow1.forEach { char ->
                        KeyButton(modifier = Modifier.weight(1f), label = char, keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(char) })
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    numRow2.forEach { char ->
                        KeyButton(modifier = Modifier.weight(1f), label = char, keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(char) })
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    KeyButton(
                        modifier = Modifier.weight(1.5f),
                        label = "=\\<",
                        keyBg = keyActiveBg,
                        textColor = textColor,
                        onClick = { layoutMode = KeyboardLayoutMode.SYMBOLS }
                    )
                    numRow3.forEach { char ->
                        KeyButton(modifier = Modifier.weight(1f), label = char, keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(char) })
                    }
                    IconButtonKey(modifier = Modifier.weight(1.5f), icon = Icons.Default.Backspace, isActive = false, activeBg = accentColor, keyBg = keyActiveBg, onClick = onDelete)
                }
            }

            KeyboardLayoutMode.SYMBOLS -> {
                val symRow1 = listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆")
                val symRow2 = listOf("£", "€", "¥", "¢", "^", "°", "=", "{", "}")
                val symRow3 = listOf("\\", "%", "<", ">", "[", "]", "©")

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    symRow1.forEach { char ->
                        KeyButton(modifier = Modifier.weight(1f), label = char, keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(char) })
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    symRow2.forEach { char ->
                        KeyButton(modifier = Modifier.weight(1f), label = char, keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(char) })
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    KeyButton(modifier = Modifier.weight(1.5f), label = "?123", keyBg = keyActiveBg, textColor = textColor, onClick = { layoutMode = KeyboardLayoutMode.NUMERIC })
                    symRow3.forEach { char ->
                        KeyButton(modifier = Modifier.weight(1f), label = char, keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(char) })
                    }
                    IconButtonKey(modifier = Modifier.weight(1.5f), icon = Icons.Default.Backspace, isActive = false, activeBg = accentColor, keyBg = keyActiveBg, onClick = onDelete)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Bottom Row: Mode Switch (?123 / ABC), Globe (Switch Keyboard), Comma, Space, Period, Enter
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val isAlpha = layoutMode == KeyboardLayoutMode.ALPHA_LOWER || layoutMode == KeyboardLayoutMode.ALPHA_UPPER
            KeyButton(
                modifier = Modifier.weight(1.3f),
                label = if (isAlpha) "?123" else "ABC",
                keyBg = keyActiveBg,
                textColor = textColor,
                onClick = {
                    layoutMode = if (isAlpha) KeyboardLayoutMode.NUMERIC else KeyboardLayoutMode.ALPHA_LOWER
                }
            )

            // Globe Key to switch between NIK-Ai board and other system keyboards
            IconButtonKey(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Language,
                isActive = false,
                activeBg = accentColor,
                keyBg = keyActiveBg,
                onClick = onSwitchKeyboard
            )

            KeyButton(modifier = Modifier.weight(0.8f), label = ",", keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(",") })

            Box(
                modifier = Modifier
                    .weight(3.8f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(keyBg)
                    .clickable { onSpace() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NIK-Ai board",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = textColor.copy(alpha = 0.45f)
                )
            }

            KeyButton(modifier = Modifier.weight(0.8f), label = ".", keyBg = keyBg, textColor = textColor, onClick = { onKeyPress(".") })

            Box(
                modifier = Modifier
                    .weight(1.4f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor)
                    .clickable { onEnter() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.KeyboardReturn,
                    contentDescription = "Enter",
                    tint = Color.Black
                )
            }
        }
    }
}

@Composable
fun KeyButton(
    modifier: Modifier = Modifier,
    label: String,
    keyBg: Color,
    textColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(keyBg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = textColor,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun IconButtonKey(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    activeBg: Color,
    keyBg: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isActive) activeBg else keyBg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isActive) Color.Black else Color.White
        )
    }
}
