package com.nikai.board

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.nikai.board.data.GeminiAiRepository
import com.nikai.board.ui.KeyboardComposeView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

data class AiResultUiState(
    val isLoading: Boolean = false,
    val activeAction: String? = null,
    val suggestions: List<String> = emptyList(),
    val primaryResult: String? = null,
    val badgeText: String? = null,
    val isOffline: Boolean = false,
    val errorMessage: String? = null
)

/**
 * NIK-Ai board: Production Android InputMethodService
 *
 * Registers with android.permission.BIND_INPUT_METHOD so it appears in Android Settings
 * under "Keyboard list and default" and replaces the existing keyboard when selected.
 * Properly attaches ViewTree Lifecycle/SavedState/ViewModelStore owners to SoftInputWindow's
 * decorView so Jetpack Compose runs reliably on Android 8-15 (API 26-35).
 */
class NikAiKeyboardService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    private lateinit var aiRepository: GeminiAiRepository

    private var isSensitiveField by mutableStateOf(false)
    private var aiUiState by mutableStateOf(AiResultUiState())

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        aiRepository = GeminiAiRepository(applicationContext)
    }

    override fun onEvaluateFullscreenMode(): Boolean {
        // Keep standard bottom-docked keyboard height so target apps remain visible
        return false
    }

    override fun onCreateInputView(): View {
        // CRITICAL: Attach ViewTree owners to SoftInputWindow's decorView for Jetpack Compose
        window?.window?.decorView?.let { decorView ->
            decorView.setViewTreeLifecycleOwner(this)
            decorView.setViewTreeViewModelStoreOwner(this)
            decorView.setViewTreeSavedStateRegistryOwner(this)
        }

        return ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@NikAiKeyboardService)
            setViewTreeViewModelStoreOwner(this@NikAiKeyboardService)
            setViewTreeSavedStateRegistryOwner(this@NikAiKeyboardService)

            setContent {
                KeyboardComposeView(
                    isSensitiveField = isSensitiveField,
                    aiUiState = aiUiState,
                    onKeyPress = { key -> handleKeyPress(key) },
                    onDelete = { handleDelete() },
                    onSpace = { handleSpace() },
                    onEnter = { handleEnter() },
                    onSwitchKeyboard = { handleSwitchKeyboard() },
                    onAiAction = { action, options -> executeAiAction(action, options) },
                    onClearAiResult = { aiUiState = AiResultUiState() },
                    onInsertText = { text -> insertText(text) },
                    onReplaceSelection = { replacement -> replaceActiveSelection(replacement) }
                )
            }
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        // Refresh API key in case user updated it in MainActivity
        aiRepository.initializeModel()

        // Evaluate sensitive field privacy safeguards (passwords, PINs, OTPs)
        isSensitiveField = isEditorSensitive(info)
        aiUiState = AiResultUiState()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        serviceScope.cancel()
        store.clear()
    }

    private fun isEditorSensitive(info: EditorInfo?): Boolean {
        if (info == null) return false
        val inputType = info.inputType
        val variation = inputType and InputType.TYPE_MASK_VARIATION

        return (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD ||
                (inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0)
    }

    fun handleKeyPress(char: String) {
        performHaptic()
        currentInputConnection?.commitText(char, 1)
    }

    fun handleDelete() {
        performHaptic()
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    fun handleSpace() {
        performHaptic()
        currentInputConnection?.commitText(" ", 1)
    }

    fun handleEnter() {
        performHaptic()
        val ic = currentInputConnection ?: return
        val editorInfo = currentInputEditorInfo
        val imeAction = editorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE

        if (imeAction != EditorInfo.IME_ACTION_NONE && imeAction != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(imeAction)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    fun handleSwitchKeyboard() {
        performHaptic()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showInputMethodPicker()
    }

    fun insertText(text: String) {
        performHaptic()
        currentInputConnection?.commitText(text, 1)
        aiUiState = AiResultUiState()
    }

    fun replaceActiveSelection(newText: String) {
        performHaptic()
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText(newText, 1)
        } else {
            val textBefore = ic.getTextBeforeCursor(1000, 0)?.toString() ?: ""
            val textAfter = ic.getTextAfterCursor(1000, 0)?.toString() ?: ""
            ic.deleteSurroundingText(textBefore.length, textAfter.length)
            ic.commitText(newText, 1)
        }
        aiUiState = AiResultUiState()
    }

    fun getActiveSurroundingText(): String {
        val ic = currentInputConnection ?: return ""
        val selected = ic.getSelectedText(0)?.toString()
        if (!selected.isNullOrEmpty()) return selected

        val before = ic.getTextBeforeCursor(500, 0)?.toString() ?: ""
        val after = ic.getTextAfterCursor(500, 0)?.toString() ?: ""
        return (before + after).trim()
    }

    fun executeAiAction(action: String, options: Map<String, Any>) {
        if (isSensitiveField) return
        val text = getActiveSurroundingText()
        if (text.isBlank() && action != "chat_generate") {
            aiUiState = AiResultUiState(
                activeAction = action,
                errorMessage = "Type or select some text first to use $action."
            )
            return
        }

        aiUiState = AiResultUiState(isLoading = true, activeAction = action)

        aiRepository.executeActionAsync(
            coroutineScope = serviceScope,
            action = action,
            text = text,
            options = options,
            onSuccess = { result ->
                val isOffline = result["isOffline"] as? Boolean ?: false
                when (action) {
                    "paraphrase" -> {
                        @Suppress("UNCHECKED_CAST")
                        val list = (result["suggestions"] as? List<*>)?.mapNotNull { it?.toString() }
                            ?: listOfNotNull(result["rawResult"]?.toString())
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            suggestions = list,
                            primaryResult = list.firstOrNull(),
                            isOffline = isOffline
                        )
                    }
                    "grammar" -> {
                        val corrected = result["correctedText"]?.toString() ?: text
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            primaryResult = corrected,
                            suggestions = listOf(corrected),
                            isOffline = isOffline
                        )
                    }
                    "translate" -> {
                        val translated = result["translatedText"]?.toString() ?: text
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            primaryResult = translated,
                            suggestions = listOf(translated),
                            isOffline = isOffline
                        )
                    }
                    "tone" -> {
                        val adjusted = result["adjustedText"]?.toString() ?: text
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            primaryResult = adjusted,
                            suggestions = listOf(adjusted),
                            isOffline = isOffline
                        )
                    }
                    "chat_generate" -> {
                        val generated = result["generatedText"]?.toString()
                            ?: result["rawResult"]?.toString() ?: ""
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            primaryResult = generated,
                            suggestions = listOf(generated),
                            isOffline = isOffline
                        )
                    }
                    "ai_detect" -> {
                        val aiProb = (result["aiProbability"] as? Number)?.toInt() ?: 25
                        val humanProb = (result["humanProbability"] as? Number)?.toInt() ?: (100 - aiProb)
                        val verdict = result["verdict"]?.toString() ?: "Analyzed"
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            badgeText = "$verdict • AI: $aiProb% | Human: $humanProb%",
                            isOffline = isOffline
                        )
                    }
                    "synonyms" -> {
                        @Suppress("UNCHECKED_CAST")
                        val rawList = result["suggestions"] as? List<Map<String, Any>> ?: emptyList()
                        val flat = rawList.flatMap { entry ->
                            val word = entry["word"]?.toString() ?: ""
                            val syns = (entry["synonyms"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
                            syns.map { syn -> "$word -> $syn" }
                        }
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            suggestions = flat,
                            isOffline = isOffline
                        )
                    }
                    else -> {
                        aiUiState = AiResultUiState(
                            activeAction = action,
                            primaryResult = result["result"]?.toString(),
                            isOffline = isOffline
                        )
                    }
                }
            },
            onError = { err ->
                aiUiState = AiResultUiState(activeAction = action, errorMessage = err)
            }
        )
    }

    private fun performHaptic() {
        val prefs = getSharedPreferences("nik_ai_board_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("haptic", true)) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                v?.vibrate(12)
            }
        } catch (_: Exception) {}
    }
}
