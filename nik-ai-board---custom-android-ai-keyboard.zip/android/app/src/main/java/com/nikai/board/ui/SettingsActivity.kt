package com.nikai.board.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nikai.board.service.FloatingOverlayWidgetService

/**
 * Settings Activity for NIK-Ai board:
 * Allows configuring themes, haptic vibration, sound, privacy shields,
 * floating overlay mode, and custom Gemini API keys.
 */
class SettingsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nik_ai_board_prefs", Context.MODE_PRIVATE)

        setContent {
            SettingsScreen(
                prefs = prefs,
                onToggleFloatingWidget = { enable ->
                    if (enable) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                            startActivity(intent)
                        } else {
                            startService(Intent(this, FloatingOverlayWidgetService::class.java))
                        }
                    } else {
                        stopService(Intent(this, FloatingOverlayWidgetService::class.java))
                    }
                }
            )
        }
    }
}

@Composable
fun SettingsScreen(
    prefs: android.content.SharedPreferences,
    onToggleFloatingWidget: (Boolean) -> Unit
) {
    var haptic by remember { mutableStateOf(prefs.getBoolean("haptic", true)) }
    var sound by remember { mutableStateOf(prefs.getBoolean("sound", false)) }
    var autoCap by remember { mutableStateOf(prefs.getBoolean("auto_cap", true)) }
    var privacyShield by remember { mutableStateOf(prefs.getBoolean("privacy_shield", true)) }
    var floatingMode by remember { mutableStateOf(prefs.getBoolean("floating_mode", false)) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_api_key", "") ?: "") }
    var selectedTheme by remember { mutableStateOf(prefs.getString("theme", "Dark AMOLED") ?: "Dark AMOLED") }
    var showApiKey by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Keyboard Settings",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Customize appearance, tactile feedback, and AI integrations",
                color = Color(0xFF94A3B8),
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Appearance & Themes
            SettingSectionHeader("Appearance")
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Keyboard Theme", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Dark AMOLED", "Slate Blue", "Light Clean").forEach { theme ->
                            FilterChip(
                                selected = selectedTheme == theme,
                                onClick = {
                                    selectedTheme = theme
                                    prefs.edit().putString("theme", theme).apply()
                                },
                                label = { Text(theme, fontSize = 12.sp) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Typing & Feedback
            SettingSectionHeader("Typing & Feedback")
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    SettingToggleRow(
                        title = "Haptic Vibration",
                        subtitle = "Gentle tick on keypress",
                        checked = haptic,
                        onCheckedChange = {
                            haptic = it
                            prefs.edit().putBoolean("haptic", it).apply()
                        }
                    )
                    Divider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 8.dp))
                    SettingToggleRow(
                        title = "Keypress Sound",
                        subtitle = "Subtle click audio",
                        checked = sound,
                        onCheckedChange = {
                            sound = it
                            prefs.edit().putBoolean("sound", it).apply()
                        }
                    )
                    Divider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 8.dp))
                    SettingToggleRow(
                        title = "Auto-Capitalization",
                        subtitle = "Capitalize first word of sentences",
                        checked = autoCap,
                        onCheckedChange = {
                            autoCap = it
                            prefs.edit().putBoolean("auto_cap", it).apply()
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Privacy & AI
            SettingSectionHeader("AI & Privacy Safeguards")
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    SettingToggleRow(
                        title = "Sensitive Text Privacy Shield",
                        subtitle = "Never send passwords, PINs, or OTPs to AI models",
                        checked = privacyShield,
                        onCheckedChange = {
                            privacyShield = it
                            prefs.edit().putBoolean("privacy_shield", it).apply()
                        }
                    )
                    Divider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 8.dp))
                    SettingToggleRow(
                        title = "Floating AI Overlay Widget Mode",
                        subtitle = "Run NIK-Ai tools as a floating pill over Gboard",
                        checked = floatingMode,
                        onCheckedChange = {
                            floatingMode = it
                            prefs.edit().putBoolean("floating_mode", it).apply()
                            onToggleFloatingWidget(it)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Standalone Deployment API Key
            SettingSectionHeader("Standalone Gemini API Key")
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Google Gemini API Key (Optional)",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Leave empty to use built-in offline fallback rules or default key",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = {
                            apiKey = it
                            prefs.edit().putString("gemini_api_key", it).apply()
                        },
                        placeholder = { Text("AIzaSy...", color = Color(0xFF64748B)) },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = Color(0xFF94A3B8)
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF10B981),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun SettingSectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        color = Color(0xFF10B981),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(text = subtitle, color = Color(0xFF94A3B8), fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
        )
    }
}
