package com.nikai.board.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Top AI Toolbar embedded directly above the QWERTY keys.
 * Offers quick action buttons for:
 * - Paraphraser (Standard, Fluency, Formal, Creative, Shorten, Expand)
 * - Real-time Grammar & Spell Checker
 * - Multi-Language Translator (30+ languages, English, Malayalam, Hindi, Spanish, etc.)
 * - AI Tone Adjuster
 * - Generative AI & Chat Drawer toggle
 * - AI Detector Badge
 * - Synonym Density Slider
 */
@Composable
fun AiToolbar(
    isSensitiveField: Boolean,
    activeTool: String?,
    onToolSelected: (String) -> Unit,
    onExecuteAi: (String, Map<String, Any>) -> Unit
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .background(Color(0xFF131D31), RoundedCornerShape(10.dp))
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // NIK AI Logo / Status Indicator
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(if (isSensitiveField) Color(0xFF64748B) else Color(0xFF10B981)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isSensitiveField) Icons.Default.Lock else Icons.Default.AutoAwesome,
                contentDescription = "NIK-Ai Status",
                tint = Color.Black,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        if (isSensitiveField) {
            Text(
                text = "Privacy Shield Active (Password/Secure Field)",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        } else {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AiToolChip(
                    label = "Paraphrase",
                    icon = Icons.Default.Transform,
                    isSelected = activeTool == "paraphrase",
                    onClick = { onToolSelected("paraphrase") }
                )
                AiToolChip(
                    label = "Grammar",
                    icon = Icons.Default.Spellcheck,
                    isSelected = activeTool == "grammar",
                    badge = "Scan",
                    onClick = { onToolSelected("grammar") }
                )
                AiToolChip(
                    label = "Translate",
                    icon = Icons.Default.Translate,
                    isSelected = activeTool == "translate",
                    onClick = { onToolSelected("translate") }
                )
                AiToolChip(
                    label = "Tone",
                    icon = Icons.Default.Psychology,
                    isSelected = activeTool == "tone",
                    onClick = { onToolSelected("tone") }
                )
                AiToolChip(
                    label = "AI Chat",
                    icon = Icons.Default.ChatBubbleOutline,
                    isSelected = activeTool == "chat",
                    onClick = { onToolSelected("chat") }
                )
                AiToolChip(
                    label = "AI Detector",
                    icon = Icons.Default.Security,
                    isSelected = activeTool == "detector",
                    onClick = { onToolSelected("detector") }
                )
                AiToolChip(
                    label = "Synonyms",
                    icon = Icons.Default.Tune,
                    isSelected = activeTool == "synonyms",
                    onClick = { onToolSelected("synonyms") }
                )
            }
        }
    }
}

@Composable
fun AiToolChip(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    badge: String? = null,
    onClick: () -> Unit
) {
    val bg = if (isSelected) Color(0xFF10B981) else Color(0xFF1E293B)
    val contentColor = if (isSelected) Color.Black else Color(0xFFF1F5F9)

    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        color = bg
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(15.dp)
            )
            Text(
                text = label,
                color = contentColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            if (badge != null && !isSelected) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF0EA5E9))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = badge,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
