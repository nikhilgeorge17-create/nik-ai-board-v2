# NIK-Ai board: Standalone Android Custom Keyboard

Production-ready Android custom soft keyboard application featuring integrated Google Gemini AI writing tools, real-time paraphraser, grammar correction, multi-language translation, tone adjuster, and smart chat drawer.

---

## 📱 Features

1. **InputMethodService Architecture**:
   - Registers system-wide in Android Settings (`android.permission.BIND_INPUT_METHOD`).
   - Lifecycle-aware input connection handling for safe text commit, selection replacement, and cursor navigation.
   - Built with modern **Jetpack Compose**.

2. **AI Toolbar directly above keys**:
   - **AI Paraphraser**: Inline rephrasing with modes: Standard, Fluency, Formal, Creative, Shorten, Expand.
   - **Grammar & Spell Checker**: Underlined suggestion spans, real-time error detection, and 1-tap "Fix All".
   - **Multi-Language Translator**: 30+ languages (English, Malayalam, Hindi, Spanish, French, German, Japanese, Arabic, etc.).
   - **AI Tone Adjuster**: Professional, Friendly, Assertive, Casual, Empathetic, Witty.
   - **Smart Chat Drawer**: Slide-over drawer with generative AI prompt presets and free-form prompt composer.
   - **AI Content Detector**: Perplexity and burstiness scan returning AI vs Human probability badge.
   - **Vocabulary & Synonym Slider**: Interactive density slider (1-5) for dynamic vocabulary replacement.
   - **Floating AI Overlay Widget Mode**: Accessibility floating pill widget running on top of Gboard or Samsung Keyboard.

3. **Privacy & Security**:
   - **Sensitive Text Privacy Shield**: Automatically detects password, PIN, OTP, and payment fields via `EditorInfo.inputType` and blocks transmission to cloud AI.
   - **Offline Fallback Engine**: If no network or API key is set, intelligent offline heuristics provide continuous typing and suggestions without disruption.

---

## 🛠️ How to Build and Run in Android Studio

1. Open Android Studio (Ladybug / Hedgehog or newer).
2. Select **Open** and choose the `android/` directory from this repository.
3. Gradle will sync dependencies automatically (Compose BOM 2024.10, Kotlin 2.0+, Google Generative AI SDK).
4. Run on an Android device or emulator running **Android 8.0 (API 26) or higher** (Target SDK 35).
5. On the device, open **NIK-Ai board** from the app launcher:
   - Step 1: Tap **Enable NIK-Ai board in System Settings** and toggle the switch.
   - Step 2: Tap **Select as Default Keyboard** and pick NIK-Ai board.
   - Step 3: Type in any app (WhatsApp, Gmail, Messages, Notes) to experience real-time AI typing!
