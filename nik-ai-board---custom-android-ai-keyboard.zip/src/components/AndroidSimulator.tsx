import React, { useState, useRef, useEffect } from 'react';
import {
  Wifi,
  BatteryCharging,
  Signal,
  MessageSquare,
  Mail,
  FileText,
  ShieldAlert,
  Settings,
  Sparkles,
  Send,
  MoreVertical,
  CheckCheck,
  Search,
  ExternalLink,
  ChevronLeft,
  ArrowRight,
  Eye,
  EyeOff,
  Move,
  Minimize2,
  Maximize2
} from 'lucide-react';
import { NikKeyboard } from './NikKeyboard';
import { InputState, isSensitiveInput } from '../utils/keyboardLogic';

export interface AndroidSimulatorProps {
  theme: 'dark' | 'slate' | 'light';
  soundEnabled: boolean;
  hapticEnabled: boolean;
  onThemeChange: (theme: 'dark' | 'slate' | 'light') => void;
  onSoundToggle: (val: boolean) => void;
  onHapticToggle: (val: boolean) => void;
}

type ActiveApp = 'chat' | 'email' | 'notes' | 'auth' | 'settings';

export const AndroidSimulator: React.FC<AndroidSimulatorProps> = ({
  theme,
  soundEnabled,
  hapticEnabled,
  onThemeChange,
  onSoundToggle,
  onHapticToggle,
}) => {
  const [activeApp, setActiveApp] = useState<ActiveApp>('chat');

  // App-specific text states
  const [chatInput, setChatInput] = useState<InputState>({
    text: 'I will prepare the presentation draft for teh meeting tomorrow.',
    selectionStart: 63,
    selectionEnd: 63,
  });

  const [chatHistory, setChatHistory] = useState([
    { sender: 'Alex (Design Lead)', text: 'Hey! Are we ready with the quarterly design review deck?', time: '10:42 AM', isMe: false },
    { sender: 'Alex (Design Lead)', text: 'Client requested we send a preview beforehand if possible.', time: '10:43 AM', isMe: false },
  ]);

  const [emailBody, setEmailBody] = useState<InputState>({
    text: 'Dear team, I want to inform you that our project is progressing good and we anticipate delivery by Friday.',
    selectionStart: 104,
    selectionEnd: 104,
  });
  const [emailSubject, setEmailSubject] = useState('Project Milestone Update');

  const [notesText, setNotesText] = useState<InputState>({
    text: 'Artificial intelligence keyboards offer predictive language modeling and automated error correction in real time directly within input fields.',
    selectionStart: 147,
    selectionEnd: 147,
  });

  const [authPassword, setAuthPassword] = useState<InputState>({
    text: 'SuperSecretPass123!',
    selectionStart: 18,
    selectionEnd: 18,
  });
  const [authPin, setAuthPin] = useState<InputState>({
    text: '9482',
    selectionStart: 4,
    selectionEnd: 4,
  });
  const [showPassword, setShowPassword] = useState(false);

  // Settings / Onboarding state inside simulator
  const [isImeEnabled, setIsImeEnabled] = useState(true);
  const [isDefaultIme, setIsDefaultIme] = useState(true);
  const [customApiKey, setCustomApiKey] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [isFloatingWidgetMode, setIsFloatingWidgetMode] = useState(false);
  const [floatingPos, setFloatingPos] = useState({ x: 20, y: 140 });
  const [isDraggingFloating, setIsDraggingFloating] = useState(false);

  // Active input tracking
  const [activeField, setActiveField] = useState<'chat' | 'email' | 'notes' | 'auth_pass' | 'auth_pin'>('chat');

  const getActiveInputState = (): InputState => {
    switch (activeField) {
      case 'chat': return chatInput;
      case 'email': return emailBody;
      case 'notes': return notesText;
      case 'auth_pass': return authPassword;
      case 'auth_pin': return authPin;
    }
  };

  const handleInputChange = (newState: InputState) => {
    switch (activeField) {
      case 'chat': setChatInput(newState); break;
      case 'email': setEmailBody(newState); break;
      case 'notes': setNotesText(newState); break;
      case 'auth_pass': setAuthPassword(newState); break;
      case 'auth_pin': setAuthPin(newState); break;
    }
  };

  const handleSendOrEnter = () => {
    if (activeApp === 'chat' && chatInput.text.trim()) {
      setChatHistory(prev => [
        ...prev,
        { sender: 'You', text: chatInput.text.trim(), time: 'Just now', isMe: true }
      ]);
      setChatInput({ text: '', selectionStart: 0, selectionEnd: 0 });
    }
  };

  const isCurrentFieldSensitive =
    activeApp === 'auth' && (activeField === 'auth_pass' || activeField === 'auth_pin');

  // Clock
  const [currentTime, setCurrentTime] = useState('10:45');
  useEffect(() => {
    const update = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-2 w-full max-w-xl mx-auto">
      {/* App Switcher Tabs at top of Simulator */}
      <div className="w-full bg-slate-900/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-800 mb-3 flex items-center justify-between gap-1 shadow-lg">
        <button
          type="button"
          onClick={() => { setActiveApp('chat'); setActiveField('chat'); }}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all ${
            activeApp === 'chat'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Chat</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveApp('email'); setActiveField('email'); }}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all ${
            activeApp === 'email'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Mail className="w-3.5 h-3.5" />
          <span>Email</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveApp('notes'); setActiveField('notes'); }}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all ${
            activeApp === 'notes'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Notes</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveApp('auth'); setActiveField('auth_pass'); }}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all ${
            activeApp === 'auth'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
          title="Test Privacy Safeguards"
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Privacy</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveApp('settings')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-semibold transition-all ${
            activeApp === 'settings'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          <span>IME Setup</span>
        </button>
      </div>

      {/* Android Device Chassis Frame */}
      <div className="w-full max-w-[420px] rounded-[38px] bg-slate-900 p-2.5 shadow-2xl border-4 border-slate-700/80 ring-1 ring-slate-800 relative select-none">
        {/* Device Outer Glow */}
        <div className="absolute inset-0 -z-10 bg-emerald-500/5 blur-xl rounded-[40px]" />

        {/* Screen Area */}
        <div className="w-full h-[620px] md:h-[635px] bg-slate-950 rounded-[30px] overflow-hidden flex flex-col justify-between border border-slate-800/80 relative">
          
          {/* Status Bar */}
          <div className="w-full h-8 px-6 bg-slate-950 flex items-center justify-between text-slate-300 text-xs font-medium z-30">
            <span>{currentTime}</span>
            {/* Center Camera Punch-hole */}
            <div className="w-4 h-4 rounded-full bg-black border border-slate-800 shadow-inner" />
            <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
              <Signal className="w-3 h-3 text-slate-200" />
              <span>5G</span>
              <Wifi className="w-3.5 h-3.5 text-slate-200" />
              <div className="flex items-center gap-0.5">
                <span>94%</span>
                <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
              </div>
            </div>
          </div>

          {/* APPLICATION VIEW PORTION */}
          <div className="flex-1 overflow-y-auto flex flex-col relative bg-slate-950">
            {/* 1. CHAT APP (WhatsApp style) */}
            {activeApp === 'chat' && (
              <div className="flex-1 flex flex-col justify-between">
                {/* Chat Header */}
                <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center font-bold text-xs text-white shadow">
                      AL
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Alex (Design Lead)</h4>
                      <p className="text-[10px] text-emerald-400">online • NIK-Ai enabled</p>
                    </div>
                  </div>
                  <MoreVertical className="w-4 h-4 text-slate-400" />
                </div>

                {/* Message Thread */}
                <div className="flex-1 p-3 space-y-2.5 overflow-y-auto text-xs">
                  {chatHistory.map((msg, i) => (
                    <div
                      key={i}
                      className={`flex flex-col ${msg.isMe ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[82%] px-3 py-2 rounded-2xl ${
                          msg.isMe
                            ? 'bg-emerald-600 text-white rounded-br-xs'
                            : 'bg-slate-800 text-slate-200 rounded-bl-xs border border-slate-700/60'
                        }`}
                      >
                        <p className="leading-relaxed">{msg.text}</p>
                        <div className="flex items-center justify-end gap-1 mt-1 text-[9px] opacity-75">
                          <span>{msg.time}</span>
                          {msg.isMe && <CheckCheck className="w-3 h-3 text-emerald-200" />}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Active Chat Input Field */}
                <div className="p-2 bg-slate-900 border-t border-slate-800">
                  <div
                    onClick={() => setActiveField('chat')}
                    className="w-full bg-slate-950 border border-emerald-500/50 rounded-xl p-2.5 min-h-[44px] text-xs text-white focus:outline-none flex items-center justify-between cursor-text"
                  >
                    <span className="flex-1 break-words">
                      {chatInput.text || <span className="text-slate-500">Type a message or use NIK-Ai...</span>}
                      <span className="inline-block w-0.5 h-3.5 bg-emerald-400 ml-0.5 animate-pulse align-middle" />
                    </span>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); handleSendOrEnter(); }}
                      className="w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950 font-bold ml-1.5 hover:bg-emerald-400"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 2. EMAIL APP (Gmail style) */}
            {activeApp === 'email' && (
              <div className="flex-1 flex flex-col p-3 space-y-3 bg-slate-950 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-emerald-400" /> Compose Email
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setEmailBody({
                        text: 'Dear Alex, following up on our project discussion. We have finalized deliverables and are ready to demo on Friday.',
                        selectionStart: 110,
                        selectionEnd: 110
                      });
                    }}
                    className="text-[10px] text-emerald-400 hover:underline"
                  >
                    Reset Template
                  </button>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 py-1 border-b border-slate-800 text-slate-400">
                    <span className="w-12 font-medium">To:</span>
                    <span className="text-slate-200">alex.lead@company.com</span>
                  </div>
                  <div className="flex items-center gap-2 py-1 border-b border-slate-800 text-slate-400">
                    <span className="w-12 font-medium">Subject:</span>
                    <span className="text-slate-200 font-semibold">{emailSubject}</span>
                  </div>
                </div>

                <div
                  onClick={() => setActiveField('email')}
                  className="flex-1 p-3 bg-slate-900/60 rounded-xl border border-slate-800 hover:border-emerald-500/40 cursor-text overflow-y-auto leading-relaxed text-slate-200"
                >
                  {emailBody.text || <span className="text-slate-500">Tap to start drafting email...</span>}
                  <span className="inline-block w-0.5 h-3.5 bg-emerald-400 ml-0.5 animate-pulse align-middle" />
                </div>
              </div>
            )}

            {/* 3. NOTES APP */}
            {activeApp === 'notes' && (
              <div className="flex-1 flex flex-col p-3 space-y-2.5 bg-slate-950 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-emerald-400" /> Research Notes
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {notesText.text.split(' ').filter(Boolean).length} words
                  </span>
                </div>

                <div
                  onClick={() => setActiveField('notes')}
                  className="flex-1 p-3 bg-slate-900/60 rounded-xl border border-slate-800 hover:border-emerald-500/40 cursor-text overflow-y-auto leading-relaxed text-slate-200"
                >
                  {notesText.text || <span className="text-slate-500">Write research thoughts...</span>}
                  <span className="inline-block w-0.5 h-3.5 bg-emerald-400 ml-0.5 animate-pulse align-middle" />
                </div>
              </div>
            )}

            {/* 4. AUTH APP (Privacy Shield Test) */}
            {activeApp === 'auth' && (
              <div className="flex-1 flex flex-col p-4 justify-center space-y-4 bg-slate-950 text-xs">
                <div className="text-center space-y-1">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 mx-auto flex items-center justify-center font-bold">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-white text-sm">Sensitive Input Privacy Shield</h3>
                  <p className="text-[11px] text-slate-400">
                    Test how NIK-Ai board immediately disables cloud AI prompts on passwords and OTP PINs.
                  </p>
                </div>

                <div className="space-y-3 bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
                  {/* Password Input */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">Account Password</label>
                    <div
                      onClick={() => setActiveField('auth_pass')}
                      className={`flex items-center justify-between p-2 rounded-lg bg-slate-950 border ${
                        activeField === 'auth_pass' ? 'border-amber-400 ring-1 ring-amber-400/30' : 'border-slate-800'
                      } cursor-pointer`}
                    >
                      <span className="font-mono text-slate-200">
                        {showPassword ? authPassword.text : '•'.repeat(authPassword.text.length)}
                        {activeField === 'auth_pass' && (
                          <span className="inline-block w-0.5 h-3.5 bg-amber-400 ml-0.5 animate-pulse align-middle" />
                        )}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); setShowPassword(!showPassword); }}
                        className="text-slate-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* 2FA PIN Input */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-300">2FA Security PIN (OTP)</label>
                    <div
                      onClick={() => setActiveField('auth_pin')}
                      className={`flex items-center justify-between p-2 rounded-lg bg-slate-950 border ${
                        activeField === 'auth_pin' ? 'border-amber-400 ring-1 ring-amber-400/30' : 'border-slate-800'
                      } cursor-pointer`}
                    >
                      <span className="font-mono tracking-widest text-slate-200">
                        {authPin.text || '••••'}
                        {activeField === 'auth_pin' && (
                          <span className="inline-block w-0.5 h-3.5 bg-amber-400 ml-0.5 animate-pulse align-middle" />
                        )}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase">
                        Zero-Log
                      </span>
                    </div>
                  </div>

                  <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-300 leading-normal">
                    🔒 Keystroke privacy verified: Password fields bypass suggestion models and API dispatch.
                  </div>
                </div>
              </div>
            )}

            {/* 5. SETTINGS / ONBOARDING SCREEN */}
            {activeApp === 'settings' && (
              <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-slate-950 text-xs">
                <div className="text-center space-y-1 py-1">
                  <div className="w-9 h-9 rounded-full bg-emerald-500 text-slate-950 mx-auto flex items-center justify-center font-bold">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-white text-sm">NIK-Ai board Setup</h3>
                  <p className="text-[11px] text-slate-400">Android System Integration &amp; Preferences</p>
                </div>

                {/* Step 1: Enable in Settings */}
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-white">1. Enable in System Settings</h4>
                      <p className="text-[10px] text-slate-400">InputMethodService registration</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsImeEnabled(!isImeEnabled)}
                      className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                        isImeEnabled
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isImeEnabled ? 'Enabled' : 'Enable'}
                    </button>
                  </div>
                </div>

                {/* Step 2: Set as Default */}
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-white">2. Set as Default Keyboard</h4>
                      <p className="text-[10px] text-slate-400">Switch from Gboard to NIK-Ai</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsDefaultIme(!isDefaultIme)}
                      className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                        isDefaultIme
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isDefaultIme ? 'Active' : 'Select'}
                    </button>
                  </div>
                </div>

                {/* Theme & Tactile Options */}
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2.5">
                  <h4 className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider">Tactile &amp; Themes</h4>
                  
                  {/* Theme Selector */}
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Theme</span>
                    <div className="flex gap-1">
                      {(['dark', 'slate', 'light'] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => onThemeChange(t)}
                          className={`px-2 py-0.5 rounded text-[10px] capitalize font-semibold ${
                            theme === t ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Sound */}
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Key Sound</span>
                    <button
                      type="button"
                      onClick={() => onSoundToggle(!soundEnabled)}
                      className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                        soundEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {soundEnabled ? 'On' : 'Off'}
                    </button>
                  </div>

                  {/* Haptics */}
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Haptic Vibration</span>
                    <button
                      type="button"
                      onClick={() => onHapticToggle(!hapticEnabled)}
                      className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                        hapticEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {hapticEnabled ? 'On' : 'Off'}
                    </button>
                  </div>

                  {/* Floating Action Widget Mode */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                    <div>
                      <span className="text-slate-300 font-semibold block">Floating AI Widget Mode</span>
                      <span className="text-[10px] text-slate-500">Overlay over Gboard/system keyboard</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsFloatingWidgetMode(!isFloatingWidgetMode)}
                      className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                        isFloatingWidgetMode ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isFloatingWidgetMode ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                </div>

                <div className="text-center pt-1">
                  <button
                    type="button"
                    onClick={() => { setActiveApp('chat'); setActiveField('chat'); }}
                    className="w-full py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs hover:bg-emerald-400 transition-colors shadow-md"
                  >
                    Open Keyboard &amp; Test Drive
                  </button>
                </div>
              </div>
            )}

            {/* FLOATING ACTION WIDGET (when enabled) */}
            {isFloatingWidgetMode && (
              <div
                style={{ top: `${floatingPos.y}px`, left: `${floatingPos.x}px` }}
                className="absolute z-40 bg-slate-900 border border-emerald-500/60 rounded-full px-3 py-1.5 shadow-2xl flex items-center gap-2 cursor-grab active:cursor-grabbing text-xs animate-in zoom-in-90"
              >
                <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950">
                  <Sparkles className="w-3 h-3" />
                </div>
                <span className="font-bold text-white text-[11px]">NIK-Ai Widget</span>
                <button
                  type="button"
                  onClick={() => setIsFloatingWidgetMode(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <Minimize2 className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          {/* DOCKED NIK-Ai SOFT KEYBOARD */}
          <div className="w-full z-20">
            <NikKeyboard
              inputState={getActiveInputState()}
              onInputChange={handleInputChange}
              isSensitiveField={isCurrentFieldSensitive}
              activeAppTitle={activeApp}
              onEnterPress={handleSendOrEnter}
              theme={theme}
              soundEnabled={soundEnabled}
              hapticEnabled={hapticEnabled}
            />
          </div>

          {/* Android Navigation Bar */}
          <div className="w-full h-4 bg-slate-950 flex items-center justify-center pb-1">
            <div className="w-28 h-1 bg-slate-600 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
