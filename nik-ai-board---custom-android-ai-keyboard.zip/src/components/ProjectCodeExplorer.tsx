import React, { useState } from 'react';
import {
  Folder,
  FileCode,
  Download,
  Copy,
  Check,
  Code2,
  FileText,
  Settings,
  Layers,
  Sparkles,
  ExternalLink,
  Smartphone,
  ChevronRight,
  Archive
} from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES, AndroidProjectFile } from '../data/androidFilesData';

export const ProjectCodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidProjectFile>(ANDROID_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const handleCopy = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder('NIK-Ai-board-Android');

      let packagedFromDisk = false;
      try {
        const res = await fetch('/api/android/files');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.files) && data.files.length > 0) {
            data.files.forEach((f: { path: string; content: string }) => {
              folder?.file(f.path, f.content);
            });
            packagedFromDisk = true;
          }
        }
      } catch {
        // Fall back to bundled file list below
      }

      if (!packagedFromDisk) {
        ANDROID_PROJECT_FILES.forEach((f) => {
          folder?.file(f.path, f.content);
        });
        folder?.file(
          'settings.gradle.kts',
          `pluginManagement {\n    repositories {\n        google()\n        mavenCentral()\n        gradlePluginPortal()\n    }\n}\ndependencyResolutionManagement {\n    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)\n    repositories {\n        google()\n        mavenCentral()\n    }\n}\nrootProject.name = "NIK-Ai board"\ninclude(":app")`
        );
        folder?.file(
          'build.gradle.kts',
          `plugins {\n    id("com.android.application") version "8.7.2" apply false\n    id("org.jetbrains.kotlin.android") version "2.0.21" apply false\n    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false\n}`
        );
        folder?.file(
          'gradle.properties',
          `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nandroid.nonTransitiveRClass=true\nkotlin.code.style=official`
        );
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'NIK-Ai-board-Android-Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to create zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const filteredFiles = filterCategory === 'all'
    ? ANDROID_PROJECT_FILES
    : ANDROID_PROJECT_FILES.filter(f => f.category === filterCategory);

  return (
    <div className="w-full max-w-6xl mx-auto p-4 space-y-4">
      {/* Top Banner & Export Actions */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 p-5 rounded-2xl border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-xs font-semibold border border-emerald-500/30">
              Android Studio Ready
            </span>
            <span className="text-slate-400 text-xs">Kotlin 2.0 • Jetpack Compose • Target SDK 35</span>
          </div>
          <h2 className="text-xl font-bold text-white mt-1">NIK-Ai board Source &amp; Gradle Project</h2>
          <p className="text-slate-400 text-xs mt-0.5 max-w-2xl leading-relaxed">
            Full physical source files for the InputMethodService, Compose Keyboard, Gemini AI Repository,
            and AndroidManifest.xml. Ready to import directly into Android Studio.
          </p>
        </div>

        <button
          type="button"
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-50 whitespace-nowrap"
        >
          <Archive className={`w-4 h-4 ${isZipping ? 'animate-bounce' : ''}`} />
          {isZipping ? 'Packaging ZIP...' : 'Download Android Project (.zip)'}
        </button>
      </div>

      {/* Main Grid: File Tree + Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: File Tree & Category Filter (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900 rounded-2xl border border-slate-800 p-4 space-y-3">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1 pb-2 border-b border-slate-800">
            {[
              { id: 'all', label: 'All Files' },
              { id: 'core', label: 'Services & AI' },
              { id: 'ui', label: 'Compose UI' },
              { id: 'config', label: 'Manifest & Gradle' },
              { id: 'res', label: 'XML Resources' },
            ].map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setFilterCategory(cat.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  filterCategory === cat.id
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* File List */}
          <div className="space-y-1 max-h-[580px] overflow-y-auto pr-1">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start gap-2.5 ${
                    isSelected
                      ? 'bg-emerald-500/10 border border-emerald-500/40 text-emerald-300'
                      : 'hover:bg-slate-800/80 text-slate-300 border border-transparent'
                  }`}
                >
                  <div className={`mt-0.5 p-1 rounded-md ${
                    file.language === 'kotlin' ? 'bg-purple-500/20 text-purple-400' :
                    file.language === 'xml' ? 'bg-amber-500/20 text-amber-400' :
                    file.language === 'gradle' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-slate-700 text-slate-300'
                  }`}>
                    <FileCode className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-mono text-xs font-semibold truncate">{file.name}</div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">{file.path}</div>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 mt-1 transition-transform ${isSelected ? 'rotate-90 text-emerald-400' : 'text-slate-600'}`} />
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{filteredFiles.length} files listed</span>
            <span className="font-mono text-emerald-400">Total ~1,200+ Lines</span>
          </div>
        </div>

        {/* Right Column: Code Viewer & Description (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden flex flex-col shadow-xl">
          {/* File Header */}
          <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-white">{selectedFile.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-mono uppercase">
                  {selectedFile.language}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate mt-0.5">{selectedFile.description}</p>
            </div>

            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all border border-slate-700"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy File'}</span>
            </button>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="p-4 bg-slate-950 overflow-x-auto max-h-[600px] text-xs font-mono leading-relaxed text-slate-300">
            <pre>
              <code>
                {selectedFile.content.split('\n').map((line, idx) => (
                  <div key={idx} className="flex hover:bg-slate-900/60 px-1 rounded">
                    <span className="w-9 select-none text-slate-600 text-right pr-4 font-mono text-[11px]">
                      {idx + 1}
                    </span>
                    <span className="flex-1 whitespace-pre">
                      {line}
                    </span>
                  </div>
                ))}
              </code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
