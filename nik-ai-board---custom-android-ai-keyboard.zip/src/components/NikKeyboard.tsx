import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Lock,
  ArrowUp,
  Delete,
  CornerDownLeft,
  RefreshCw,
  SpellCheck,
  Languages,
  Smile,
  Sliders,
  ShieldCheck,
  MessageSquarePlus,
  Send,
  X,
  Check,
  ChevronRight,
  Flame,
  Volume2,
  VolumeX,
  Vibrate,
  Globe,
  SlidersHorizontal,
  ChevronDown
} from 'lucide-react';
import { keyboardAudio } from '../utils/soundEffects';
import {
  commitText,
  deleteSurroundingText,
  getCurrentWordAtCursor,
  filterSynonymsByDensity,
  InputState
} from '../utils/keyboardLogic';

export interface NikKeyboardProps {
  inputState: InputState;
  onInputChange: (newState: InputState) => void;
  isSensitiveField: boolean;
  activeAppTitle: string;
  onEnterPress: () => void;
  theme?: 'dark' | 'slate' | 'light';
  soundEnabled: boolean;
  hapticEnabled: boolean;
}

type ToolType = 'paraphrase' | 'grammar' | 'translate' | 'tone' | 'chat' | 'detector' | 'synonyms' | null;

export const NikKeyboard: React.FC<NikKeyboardProps> = ({
  inputState,
  onInputChange,
  isSensitiveField,
  activeAppTitle,
  onEnterPress,
  theme = 'dark',
  soundEnabled,
  hapticEnabled,
}) => {
  const [layoutMode, setLayoutMode] = useState<'alpha' | 'numeric' | 'symbols' | 'emoji'>('alpha');
  const [isShifted, setIsShifted] = useState(false);
  const [isCapsLock, setIsCapsLock] = useState(false);
  const [activeTool, setActiveTool] = useState<ToolType>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  // Tool Specific States
  // 1. Paraphrase
  const [paraphraseMode, setParaphraseMode] = useState<'standard' | 'fluency' | 'formal' | 'creative' | 'shorten' | 'expand'>('standard');
  const [paraphraseResults, setParaphraseResults] = useState<string[]>([]);

  // 2. Grammar
  const [grammarErrors, setGrammarErrors] = useState<any[]>([]);
  const [grammarCorrected, setGrammarCorrected] = useState<string>('');
  const [grammarStatus, setGrammarStatus] = useState<'clean' | 'issues_detected' | 'idle'>('idle');

  // 3. Translate
  const [targetLang, setTargetLang] = useState<string>('Malayalam');
  const [translatedText, setTranslatedText] = useState<string>('');

  // 4. Tone
  const [activeTone, setActiveTone] = useState<string>('Professional');
  const [toneResults, setToneResults] = useState<{ adjustedText: string; alternatives?: string[] } | null>(null);

  // 5. Chat Drawer
  const [chatPrompt, setChatPrompt] = useState<string>('');
  const [chatGeneratedText, setChatGeneratedText] = useState<string>('');

  // 6. Detector
  const [detectorResult, setDetectorResult] = useState<{ aiProbability: number; humanProbability: number; verdict: string; highlightNotes: string } | null>(null);

  // 7. Synonyms
  const [synonymDensity, setSynonymDensity] = useState<number>(3);
  const [synonymList, setSynonymList] = useState<Array<{ word: string; synonyms: string[] }>>([]);

  const backspaceTimerRef = useRef<any>(null);

  useEffect(() => {
    keyboardAudio.enabled = soundEnabled;
  }, [soundEnabled]);

  const triggerHaptic = () => {
    if (hapticEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(10);
      } catch {}
    }
  };

  const handleCharPress = (char: string) => {
    if (soundEnabled) keyboardAudio.playKeyClick();
    triggerHaptic();

    const outputChar = isShifted || isCapsLock ? char.toUpperCase() : char.toLowerCase();
    const updated = commitText(inputState, outputChar);
    onInputChange(updated);

    // If single-shift was on, revert
    if (isShifted && !isCapsLock) {
      setIsShifted(false);
    }
  };

  const handleDelete = () => {
    if (soundEnabled) keyboardAudio.playSpecialClick();
    triggerHaptic();
    const updated = deleteSurroundingText(inputState, 1, 0);
    onInputChange(updated);
  };

  const handleSpace = () => {
    if (soundEnabled) keyboardAudio.playKeyClick();
    triggerHaptic();
    const updated = commitText(inputState, ' ');
    onInputChange(updated);
  };

  const handleEnter = () => {
    if (soundEnabled) keyboardAudio.playSpecialClick();
    triggerHaptic();
    onEnterPress();
  };

  // Execute AI action on Express backend
  const executeAi = async (tool: ToolType, extraOptions: any = {}) => {
    if (isSensitiveField) return;
    const textToProcess = inputState.text;
    if (!textToProcess.trim() && tool !== 'chat') return;

    setIsLoadingAi(true);
    try {
      let actionName = tool as string;
      if (tool === 'detector') actionName = 'ai_detect';
      if (tool === 'chat') actionName = 'chat_generate';

      const res = await fetch('/api/ai/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: actionName,
          text: textToProcess,
          options: extraOptions,
        }),
      });

      const data = await res.json();

      if (tool === 'paraphrase') {
        setParaphraseResults(data.suggestions || [data.result || '']);
      } else if (tool === 'grammar') {
        setGrammarCorrected(data.correctedText || textToProcess);
        setGrammarErrors(data.errors || []);
        setGrammarStatus(data.errors && data.errors.length > 0 ? 'issues_detected' : 'clean');
      } else if (tool === 'translate') {
        setTranslatedText(data.translatedText || '');
      } else if (tool === 'tone') {
        setToneResults({
          adjustedText: data.adjustedText || '',
          alternatives: data.alternatives || [],
        });
      } else if (tool === 'chat') {
        setChatGeneratedText(data.generatedText || '');
      } else if (tool === 'detector') {
        setDetectorResult(data);
      } else if (tool === 'synonyms') {
        setSynonymList(filterSynonymsByDensity(data.suggestions || [], extraOptions.density || synonymDensity));
      }
    } catch (err) {
      console.warn('AI processing error, fallback active:', err);
    } finally {
      setIsLoadingAi(false);
    }
  };

  const toggleTool = (tool: ToolType) => {
    if (activeTool === tool) {
      setActiveTool(null);
    } else {
      setActiveTool(tool);
      // Auto run on open if text is present
      if (tool === 'paraphrase') executeAi('paraphrase', { mode: paraphraseMode });
      if (tool === 'grammar') executeAi('grammar');
      if (tool === 'translate') executeAi('translate', { targetLang });
      if (tool === 'tone') executeAi('tone', { tone: activeTone });
      if (tool === 'detector') executeAi('detector');
      if (tool === 'synonyms') executeAi('synonyms', { density: synonymDensity });
    }
  };

  const applyTextReplacement = (newText: string) => {
    onInputChange({
      text: newText,
      selectionStart: newText.length,
      selectionEnd: newText.length,
    });
    setActiveTool(null);
    triggerHaptic();
  };

  const applySingleWordSynonym = (targetWord: string, synonym: string) => {
    const reg = new RegExp(`\\b${targetWord}\\b`, 'i');
    const updated = inputState.text.replace(reg, synonym);
    onInputChange({
      text: updated,
      selectionStart: updated.length,
      selectionEnd: updated.length,
    });
    triggerHaptic();
  };

  // Keyboard theme colors
  const themeBg = theme === 'light' ? 'bg-slate-100' : theme === 'slate' ? 'bg-slate-900' : 'bg-slate-950';
  const keyBg = theme === 'light' ? 'bg-white text-slate-800 shadow-sm border border-slate-200' : theme === 'slate' ? 'bg-slate-800 text-slate-100 shadow' : 'bg-slate-900 text-slate-100 shadow-sm border border-slate-800/80';
  const specialKeyBg = theme === 'light' ? 'bg-slate-200 text-slate-700' : theme === 'slate' ? 'bg-slate-700 text-slate-200' : 'bg-slate-800 text-slate-300';

  const row1Letters = ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'];
  const row2Letters = ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'];
  const row3Letters = ['z', 'x', 'c', 'v', 'b', 'n', 'm'];

  const numRow1 = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
  const numRow2 = ['@', '#', '$', '%', '&', '-', '+', '(', ')', '/'];
  const numRow3 = ['*', '"', '\'', ':', ';', '!', '?', ','];

  const symRow1 = ['~', '`', '|', '•', '√', 'π', '÷', '×', '¶', '∆'];
  const symRow2 = ['£', '€', '¥', '¢', '^', '°', '=', '{', '}', '\\'];
  const symRow3 = ['%', '<', '>', '[', ']', '©', '®', '™'];

  const majorLanguages = [
    'Malayalam', 'Hindi', 'Spanish', 'French', 'German',
    'Japanese', 'Arabic', 'Chinese', 'Portuguese', 'Russian',
    'Italian', 'Korean', 'Tamil', 'Telugu', 'Bengali', 'Dutch'
  ];

  const toneOptions = ['Professional', 'Friendly', 'Assertive', 'Casual', 'Empathetic', 'Witty', 'Academic'];

  return (
    <div className={`w-full ${themeBg} border-t border-slate-800/80 flex flex-col select-none transition-colors duration-200`}>
      {/* 1. TOP AI TOOLBAR */}
      <div className="w-full px-2 py-1.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-1.5 text-xs">
        {/* NIK-Ai Logo / Privacy Indicator */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center font-bold transition-all shadow-sm ${
              isSensitiveField
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
            }`}
            title={isSensitiveField ? 'Sensitive Field - Privacy Shield Active' : 'NIK-Ai Active'}
          >
            {isSensitiveField ? <Lock className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5 animate-pulse" />}
          </div>
        </div>

        {isSensitiveField ? (
          <div className="flex-1 flex items-center justify-center text-[11px] text-amber-400 font-medium px-2 py-1 bg-amber-500/10 rounded-md border border-amber-500/20">
            <Lock className="w-3 h-3 mr-1.5 inline" />
            Sensitive field: AI auto-disabled to protect privacy
          </div>
        ) : (
          <div className="flex-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth py-0.5 px-1">
            {/* Paraphrase */}
            <button
              type="button"
              onClick={() => toggleTool('paraphrase')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTool === 'paraphrase'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800/90 text-slate-200 hover:bg-slate-700/80'
              }`}
            >
              <RefreshCw className={`w-3 h-3 ${isLoadingAi && activeTool === 'paraphrase' ? 'animate-spin' : ''}`} />
              Paraphrase
            </button>

            {/* Grammar */}
            <button
              type="button"
              onClick={() => toggleTool('grammar')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all relative ${
                activeTool === 'grammar'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800/90 text-slate-200 hover:bg-slate-700/80'
              }`}
            >
              <SpellCheck className={`w-3 h-3 ${isLoadingAi && activeTool === 'grammar' ? 'animate-spin' : ''}`} />
              Grammar
              {grammarErrors.length > 0 && activeTool !== 'grammar' && (
                <span className="w-2 h-2 rounded-full bg-rose-500 absolute -top-0.5 -right-0.5 ring-2 ring-slate-900" />
              )}
            </button>

            {/* Translate */}
            <button
              type="button"
              onClick={() => toggleTool('translate')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTool === 'translate'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800/90 text-slate-200 hover:bg-slate-700/80'
              }`}
            >
              <Languages className={`w-3 h-3 ${isLoadingAi && activeTool === 'translate' ? 'animate-spin' : ''}`} />
              Translate
              <span className="text-[10px] opacity-75 font-mono">({targetLang.slice(0, 3)})</span>
            </button>

            {/* Tone */}
            <button
              type="button"
              onClick={() => toggleTool('tone')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTool === 'tone'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800/90 text-slate-200 hover:bg-slate-700/80'
              }`}
            >
              <Smile className={`w-3 h-3 ${isLoadingAi && activeTool === 'tone' ? 'animate-spin' : ''}`} />
              Tone
            </button>

            {/* AI Smart Chat Drawer */}
            <button
              type="button"
              onClick={() => toggleTool('chat')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTool === 'chat'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800/90 text-slate-200 hover:bg-slate-700/80'
              }`}
            >
              <MessageSquarePlus className="w-3 h-3" />
              AI Chat & Draft
            </button>

            {/* AI Detector */}
            <button
              type="button"
              onClick={() => toggleTool('detector')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTool === 'detector'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800/90 text-slate-200 hover:bg-slate-700/80'
              }`}
            >
              <ShieldCheck className={`w-3 h-3 ${isLoadingAi && activeTool === 'detector' ? 'animate-spin' : ''}`} />
              AI Detector
            </button>

            {/* Synonym Density Slider */}
            <button
              type="button"
              onClick={() => toggleTool('synonyms')}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTool === 'synonyms'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800/90 text-slate-200 hover:bg-slate-700/80'
              }`}
            >
              <Sliders className="w-3 h-3" />
              Synonyms
            </button>
          </div>
        )}
      </div>

      {/* 2. EXPANDED AI TOOL SHEETS */}
      {activeTool && !isSensitiveField && (
        <div className="w-full bg-slate-900 border-b border-slate-800 p-2 animate-in slide-in-from-top-2 duration-150 max-h-36 md:max-h-40 overflow-y-auto">
          {/* Header of sheet */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                {activeTool === 'paraphrase' && 'AI Paraphraser'}
                {activeTool === 'grammar' && 'Real-time Grammar & Spell Checker'}
                {activeTool === 'translate' && `Multi-Language Translator (${targetLang})`}
                {activeTool === 'tone' && `AI Tone Adjuster (${activeTone})`}
                {activeTool === 'chat' && 'AI Smart Chat & Generative Reply'}
                {activeTool === 'detector' && 'AI Content Detector'}
                {activeTool === 'synonyms' && `Vocabulary & Synonym Density (${synonymDensity}/5)`}
              </span>
              {isLoadingAi && (
                <span className="text-[10px] text-emerald-300 animate-pulse font-mono flex items-center gap-1">
                  <RefreshCw className="w-2.5 h-2.5 animate-spin" /> Thinking...
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={() => setActiveTool(null)}
              className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* TOOL 1: PARAPHRASER */}
          {activeTool === 'paraphrase' && (
            <div className="space-y-2">
              {/* Mode Buttons */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
                {(['standard', 'fluency', 'formal', 'creative', 'shorten', 'expand'] as const).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => {
                      setParaphraseMode(mode);
                      executeAi('paraphrase', { mode });
                    }}
                    className={`px-2 py-0.5 rounded-full capitalize font-medium transition-all ${
                      paraphraseMode === mode
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>

              {/* Suggestions */}
              {paraphraseResults.length > 0 ? (
                <div className="space-y-1.5">
                  {paraphraseResults.map((sug, i) => (
                    <div
                      key={i}
                      className="p-2 rounded-lg bg-slate-800/80 border border-slate-700/60 hover:border-emerald-500/50 flex items-start justify-between gap-2 group transition-all"
                    >
                      <p className="text-xs text-slate-200 flex-1 leading-relaxed">{sug}</p>
                      <button
                        type="button"
                        onClick={() => applyTextReplacement(sug)}
                        className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 text-[11px] font-semibold transition-all flex items-center gap-1"
                      >
                        <Check className="w-3 h-3" /> Apply
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-2 text-xs text-slate-400">
                  {inputState.text.trim() ? 'Generating alternatives...' : 'Type text above to paraphrase'}
                </div>
              )}
            </div>
          )}

          {/* TOOL 2: GRAMMAR */}
          {activeTool === 'grammar' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">
                  {grammarErrors.length === 0
                    ? '✨ Text looks clear and grammatically sound!'
                    : `Found ${grammarErrors.length} improvement${grammarErrors.length > 1 ? 's' : ''}`}
                </span>
                {grammarErrors.length > 0 && (
                  <button
                    type="button"
                    onClick={() => applyTextReplacement(grammarCorrected)}
                    className="px-2.5 py-1 rounded-md bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-all flex items-center gap-1"
                  >
                    <Check className="w-3 h-3" /> Fix All
                  </button>
                )}
              </div>

              {grammarErrors.length > 0 ? (
                <div className="space-y-1.5">
                  {grammarErrors.map((err, i) => (
                    <div
                      key={i}
                      className="p-2 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-between gap-2 text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="line-through text-rose-400 font-medium">{err.original}</span>
                          <span className="text-slate-500">→</span>
                          <span className="text-emerald-400 font-semibold">{err.suggestion}</span>
                        </div>
                        <span className="text-[10px] text-slate-400">{err.reason}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const reg = new RegExp(`\\b${err.original}\\b`, 'i');
                          const fixed = inputState.text.replace(reg, err.suggestion);
                          onInputChange({ text: fixed, selectionStart: fixed.length, selectionEnd: fixed.length });
                          setGrammarErrors(grammarErrors.filter((_, idx) => idx !== i));
                        }}
                        className="px-2 py-0.5 rounded bg-slate-700 text-slate-200 hover:bg-emerald-500 hover:text-slate-950 text-[10px] font-bold transition-all"
                      >
                        Accept
                      </button>
                    </div>
                  ))}
                </div>
              ) : grammarCorrected && grammarCorrected !== inputState.text ? (
                <div className="p-2 rounded bg-slate-800/80 border border-emerald-500/30 flex items-center justify-between">
                  <p className="text-xs text-slate-200">{grammarCorrected}</p>
                  <button
                    type="button"
                    onClick={() => applyTextReplacement(grammarCorrected)}
                    className="px-2 py-1 rounded bg-emerald-500 text-slate-950 text-xs font-bold"
                  >
                    Apply Polish
                  </button>
                </div>
              ) : null}
            </div>
          )}

          {/* TOOL 3: TRANSLATE */}
          {activeTool === 'translate' && (
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
                {majorLanguages.map((lang) => (
                  <button
                    key={lang}
                    type="button"
                    onClick={() => {
                      setTargetLang(lang);
                      executeAi('translate', { targetLang: lang });
                    }}
                    className={`px-2 py-0.5 rounded-full font-medium transition-all ${
                      targetLang === lang
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {lang}
                  </button>
                ))}
              </div>

              {translatedText ? (
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 space-y-2">
                  <div className="text-xs text-slate-100 font-medium leading-relaxed">
                    {translatedText}
                  </div>
                  <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-700/60">
                    <button
                      type="button"
                      onClick={() => {
                        const appended = `${inputState.text}\n${translatedText}`;
                        onInputChange({ text: appended, selectionStart: appended.length, selectionEnd: appended.length });
                        setActiveTool(null);
                      }}
                      className="px-2 py-1 rounded bg-slate-700 text-slate-300 hover:bg-slate-600 text-xs font-medium"
                    >
                      Append below
                    </button>
                    <button
                      type="button"
                      onClick={() => applyTextReplacement(translatedText)}
                      className="px-2.5 py-1 rounded bg-emerald-500 text-slate-950 text-xs font-bold hover:bg-emerald-400"
                    >
                      Replace in field
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-2 text-xs text-slate-400">
                  {inputState.text.trim() ? 'Translating text...' : 'Type text above to translate'}
                </div>
              )}
            </div>
          )}

          {/* TOOL 4: TONE */}
          {activeTool === 'tone' && (
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
                {toneOptions.map((tone) => (
                  <button
                    key={tone}
                    type="button"
                    onClick={() => {
                      setActiveTone(tone);
                      executeAi('tone', { tone });
                    }}
                    className={`px-2.5 py-0.5 rounded-full font-medium transition-all ${
                      activeTone === tone
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {tone}
                  </button>
                ))}
              </div>

              {toneResults?.adjustedText ? (
                <div className="p-2.5 rounded-lg bg-slate-800 border border-slate-700 space-y-2">
                  <p className="text-xs text-slate-100 leading-relaxed">{toneResults.adjustedText}</p>
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => applyTextReplacement(toneResults.adjustedText)}
                      className="px-2.5 py-1 rounded bg-emerald-500 text-slate-950 text-xs font-bold hover:bg-emerald-400"
                    >
                      Apply {activeTone} Tone
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-2 text-xs text-slate-400">
                  {inputState.text.trim() ? 'Adjusting tone...' : 'Type text above to transform tone'}
                </div>
              )}
            </div>
          )}

          {/* TOOL 5: CHAT DRAWER */}
          {activeTool === 'chat' && (
            <div className="space-y-2">
              {/* Preset prompt pills */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
                {[
                  'Draft a polite decline email',
                  'Summarize in 2 sentences',
                  'Draft quick status update',
                  'Write professional follow-up',
                  'Express sincere gratitude',
                ].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      setChatPrompt(preset);
                      executeAi('chat', { prompt: preset, contextText: inputState.text });
                    }}
                    className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 hover:bg-slate-700 whitespace-nowrap"
                  >
                    {preset}
                  </button>
                ))}
              </div>

              {/* Input Prompt row */}
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={chatPrompt}
                  onChange={(e) => setChatPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      executeAi('chat', { prompt: chatPrompt, contextText: inputState.text });
                    }
                  }}
                  placeholder="Ask Gemini to draft, reply, or compose..."
                  className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => executeAi('chat', { prompt: chatPrompt, contextText: inputState.text })}
                  disabled={isLoadingAi || !chatPrompt.trim()}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 disabled:opacity-50 text-xs flex items-center gap-1"
                >
                  <Send className="w-3 h-3" />
                </button>
              </div>

              {chatGeneratedText && (
                <div className="p-2.5 rounded-lg bg-slate-800 border border-emerald-500/40 space-y-2">
                  <p className="text-xs text-slate-200 leading-relaxed">{chatGeneratedText}</p>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => applyTextReplacement(chatGeneratedText)}
                      className="px-2.5 py-1 rounded bg-emerald-500 text-slate-950 text-xs font-bold hover:bg-emerald-400"
                    >
                      Insert into Field
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TOOL 6: AI DETECTOR */}
          {activeTool === 'detector' && (
            <div className="space-y-2">
              {detectorResult ? (
                <div className="p-2.5 rounded-lg bg-slate-800 border border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-400">Content Verdict: </span>
                      <span className="text-xs font-bold text-emerald-400">{detectorResult.verdict}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold">
                        AI: {detectorResult.aiProbability}%
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                        Human: {detectorResult.humanProbability}%
                      </span>
                    </div>
                  </div>

                  {/* Probability Bar */}
                  <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden flex">
                    <div
                      style={{ width: `${detectorResult.aiProbability}%` }}
                      className="bg-rose-500 h-full transition-all duration-300"
                    />
                    <div
                      style={{ width: `${detectorResult.humanProbability}%` }}
                      className="bg-emerald-500 h-full transition-all duration-300"
                    />
                  </div>

                  <p className="text-[11px] text-slate-400 italic">
                    {detectorResult.highlightNotes || 'Analyzed semantic entropy and sentence burstiness.'}
                  </p>
                </div>
              ) : (
                <div className="text-center py-2 text-xs text-slate-400">
                  {inputState.text.trim() ? 'Scanning text for AI signatures...' : 'Type text above to run AI detection'}
                </div>
              )}
            </div>
          )}

          {/* TOOL 7: SYNONYMS SLIDER */}
          {activeTool === 'synonyms' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span className="flex items-center gap-1">
                  <SlidersHorizontal className="w-3 h-3 text-emerald-400" />
                  Synonym Density: <strong>Level {synonymDensity}</strong>
                </span>
                <span className="text-[10px] text-slate-400">
                  {synonymDensity <= 2 ? 'Subtle' : synonymDensity <= 4 ? 'Moderate' : 'Advanced / Academic'}
                </span>
              </div>

              {/* Slider */}
              <input
                type="range"
                min="1"
                max="5"
                step="1"
                value={synonymDensity}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setSynonymDensity(val);
                  executeAi('synonyms', { density: val });
                }}
                className="w-full accent-emerald-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
              />

              {synonymList.length > 0 ? (
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Tap a synonym to replace:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {synonymList.map((item, i) => (
                      <div key={i} className="flex items-center gap-1 bg-slate-800 p-1 rounded-md border border-slate-700 text-xs">
                        <span className="font-semibold text-slate-300 pl-1">{item.word}:</span>
                        {item.synonyms.map((syn, synIdx) => (
                          <button
                            key={synIdx}
                            type="button"
                            onClick={() => applySingleWordSynonym(item.word, syn)}
                            className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 text-[11px] font-medium transition-all"
                          >
                            {syn}
                          </button>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-2 text-xs text-slate-400">
                  {inputState.text.trim() ? 'Identifying vocabulary alternatives...' : 'Type text above to explore synonyms'}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 3. KEYBOARD KEYS */}
      <div className="w-full p-1.5 space-y-1.5">
        {/* ALPHA LAYOUT */}
        {layoutMode === 'alpha' && (
          <>
            {/* ROW 1 */}
            <div className="flex items-center justify-center gap-1 w-full">
              {row1Letters.map((char) => {
                const display = isShifted || isCapsLock ? char.toUpperCase() : char;
                return (
                  <button
                    key={char}
                    type="button"
                    onClick={() => handleCharPress(char)}
                    className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                  >
                    {display}
                  </button>
                );
              })}
            </div>

            {/* ROW 2 */}
            <div className="flex items-center justify-center gap-1 w-full px-2">
              {row2Letters.map((char) => {
                const display = isShifted || isCapsLock ? char.toUpperCase() : char;
                return (
                  <button
                    key={char}
                    type="button"
                    onClick={() => handleCharPress(char)}
                    className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                  >
                    {display}
                  </button>
                );
              })}
            </div>

            {/* ROW 3 with SHIFT & BACKSPACE */}
            <div className="flex items-center justify-center gap-1 w-full">
              {/* SHIFT */}
              <button
                type="button"
                onClick={() => {
                  if (isShifted && !isCapsLock) {
                    setIsCapsLock(true);
                  } else if (isCapsLock) {
                    setIsCapsLock(false);
                    setIsShifted(false);
                  } else {
                    setIsShifted(true);
                  }
                  if (soundEnabled) keyboardAudio.playSpecialClick();
                }}
                className={`w-11 h-10 rounded-md flex items-center justify-center transition-all ${
                  isCapsLock
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : isShifted
                    ? 'bg-slate-700 text-emerald-400'
                    : specialKeyBg
                }`}
                title="Shift / Caps Lock"
              >
                <ArrowUp className={`w-4 h-4 ${isCapsLock ? 'stroke-[3]' : ''}`} />
              </button>

              {row3Letters.map((char) => {
                const display = isShifted || isCapsLock ? char.toUpperCase() : char;
                return (
                  <button
                    key={char}
                    type="button"
                    onClick={() => handleCharPress(char)}
                    className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                  >
                    {display}
                  </button>
                );
              })}

              {/* BACKSPACE */}
              <button
                type="button"
                onClick={handleDelete}
                className={`w-11 h-10 rounded-md ${specialKeyBg} active:scale-95 transition-transform flex items-center justify-center`}
                title="Backspace"
              >
                <Delete className="w-4 h-4" />
              </button>
            </div>
          </>
        )}

        {/* NUMERIC LAYOUT */}
        {layoutMode === 'numeric' && (
          <>
            <div className="flex items-center justify-center gap-1 w-full">
              {numRow1.map((char) => (
                <button
                  key={char}
                  type="button"
                  onClick={() => handleCharPress(char)}
                  className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                >
                  {char}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-center gap-1 w-full px-1">
              {numRow2.map((char) => (
                <button
                  key={char}
                  type="button"
                  onClick={() => handleCharPress(char)}
                  className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                >
                  {char}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-center gap-1 w-full">
              <button
                type="button"
                onClick={() => setLayoutMode('symbols')}
                className={`w-12 h-10 rounded-md font-bold text-xs ${specialKeyBg} active:scale-95 transition-transform flex items-center justify-center`}
              >
                =\&lt;
              </button>
              {numRow3.map((char) => (
                <button
                  key={char}
                  type="button"
                  onClick={() => handleCharPress(char)}
                  className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                >
                  {char}
                </button>
              ))}
              <button
                type="button"
                onClick={handleDelete}
                className={`w-12 h-10 rounded-md ${specialKeyBg} active:scale-95 transition-transform flex items-center justify-center`}
              >
                <Delete className="w-4 h-4" />
              </button>
            </div>
          </>
        )}

        {/* SYMBOLS LAYOUT */}
        {layoutMode === 'symbols' && (
          <>
            <div className="flex items-center justify-center gap-1 w-full">
              {symRow1.map((char) => (
                <button
                  key={char}
                  type="button"
                  onClick={() => handleCharPress(char)}
                  className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                >
                  {char}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-center gap-1 w-full px-1">
              {symRow2.map((char) => (
                <button
                  key={char}
                  type="button"
                  onClick={() => handleCharPress(char)}
                  className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                >
                  {char}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-center gap-1 w-full">
              <button
                type="button"
                onClick={() => setLayoutMode('numeric')}
                className={`w-12 h-10 rounded-md font-bold text-xs ${specialKeyBg} active:scale-95 transition-transform flex items-center justify-center`}
              >
                ?123
              </button>
              {symRow3.map((char) => (
                <button
                  key={char}
                  type="button"
                  onClick={() => handleCharPress(char)}
                  className={`flex-1 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
                >
                  {char}
                </button>
              ))}
              <button
                type="button"
                onClick={handleDelete}
                className={`w-12 h-10 rounded-md ${specialKeyBg} active:scale-95 transition-transform flex items-center justify-center`}
              >
                <Delete className="w-4 h-4" />
              </button>
            </div>
          </>
        )}

        {/* EMOJI LAYOUT */}
        {layoutMode === 'emoji' && (
          <div className="h-32 overflow-y-auto grid grid-cols-8 gap-1 p-1 bg-slate-900/60 rounded-md">
            {[
              '😊', '😂', '👍', '❤️', '🔥', '✨', '🎉', '🚀',
              '🙏', '💡', '🤝', '🙌', '💯', '👏', '🎯', '⚡',
              '😎', '🤔', '💪', '⭐', '🏆', '👋', '👀', '💼',
              '📊', '✅', '📩', '📝', '🌟', '🥳', '😉', '👌'
            ].map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => handleCharPress(emoji)}
                className="h-9 rounded flex items-center justify-center text-lg hover:bg-slate-800 active:scale-95 transition-all"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

        {/* BOTTOM ROW: Switch, Comma, Spacebar, Period, Enter */}
        <div className="flex items-center justify-center gap-1.5 w-full pt-0.5">
          {/* Mode Switch Button */}
          <button
            type="button"
            onClick={() => {
              if (soundEnabled) keyboardAudio.playSpecialClick();
              if (layoutMode === 'alpha') setLayoutMode('numeric');
              else setLayoutMode('alpha');
            }}
            className={`w-12 h-10 rounded-md font-bold text-xs ${specialKeyBg} active:scale-95 transition-transform flex items-center justify-center`}
          >
            {layoutMode === 'alpha' ? '?123' : 'ABC'}
          </button>

          {/* Emoji Switch Button */}
          <button
            type="button"
            onClick={() => {
              if (soundEnabled) keyboardAudio.playSpecialClick();
              setLayoutMode(layoutMode === 'emoji' ? 'alpha' : 'emoji');
            }}
            className={`w-9 h-10 rounded-md ${specialKeyBg} active:scale-95 transition-transform flex items-center justify-center text-slate-300`}
            title="Emoji drawer"
          >
            <Smile className="w-4 h-4" />
          </button>

          {/* Comma */}
          <button
            type="button"
            onClick={() => handleCharPress(',')}
            className={`w-8 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
          >
            ,
          </button>

          {/* Spacebar */}
          <button
            type="button"
            onClick={handleSpace}
            className={`flex-1 h-10 rounded-md ${keyBg} active:scale-[0.99] transition-transform flex items-center justify-center relative overflow-hidden group`}
          >
            <span className="text-[11px] font-semibold text-slate-400 group-hover:text-emerald-400 transition-colors flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5 text-emerald-500" /> NIK-Ai board
            </span>
          </button>

          {/* Period */}
          <button
            type="button"
            onClick={() => handleCharPress('.')}
            className={`w-8 h-10 rounded-md font-semibold text-sm ${keyBg} active:scale-95 transition-transform flex items-center justify-center`}
          >
            .
          </button>

          {/* Enter Key */}
          <button
            type="button"
            onClick={handleEnter}
            className="w-12 h-10 rounded-md bg-emerald-500 text-slate-950 font-bold active:scale-95 transition-transform flex items-center justify-center shadow-md shadow-emerald-500/20 hover:bg-emerald-400"
            title="Send / Return"
          >
            <CornerDownLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
