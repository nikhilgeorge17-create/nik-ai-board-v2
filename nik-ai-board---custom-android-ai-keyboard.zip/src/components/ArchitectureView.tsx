import React from 'react';
import {
  Cpu,
  Layers,
  ShieldCheck,
  Zap,
  ArrowRight,
  Sparkles,
  Smartphone,
  Server,
  Lock,
  CheckCircle2,
  XCircle,
  HelpCircle
} from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  return (
    <div className="w-full max-w-6xl mx-auto p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2 max-w-3xl mx-auto">
        <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-xs font-semibold border border-emerald-500/30">
          Android InputMethodService &amp; Gemini Architecture
        </span>
        <h2 className="text-2xl font-extrabold text-white">System Architecture &amp; Lifecycle Specifications</h2>
        <p className="text-slate-400 text-xs leading-relaxed">
          How NIK-Ai board hooks natively into Android's low-level Input Method framework, executes Jetpack Compose rendering,
          and processes AI requests asynchronously without stuttering 60fps keypress pipelines.
        </p>
      </div>

      {/* Architecture Flow Diagram */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-400" />
          End-to-End Keypress &amp; AI Execution Pipeline
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
          {/* Step 1 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                PHASE 1
              </span>
              <Smartphone className="w-4 h-4 text-slate-500" />
            </div>
            <h4 className="font-bold text-white text-xs">Target App Focus</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Android OS fires <code className="text-emerald-300">onStartInputView(EditorInfo)</code>.
              NIK-Ai checks <code className="text-emerald-300">EditorInfo.inputType</code> for password/PIN flags.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-bold">
                PHASE 2
              </span>
              <Cpu className="w-4 h-4 text-slate-500" />
            </div>
            <h4 className="font-bold text-white text-xs">ComposeView Render</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Keyboard layout and AI Toolbar mount inside <code className="text-blue-300">onCreateInputView()</code> with ViewTreeLifecycleOwner and hardware tactile haptics.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 font-bold">
                PHASE 3
              </span>
              <Sparkles className="w-4 h-4 text-slate-500" />
            </div>
            <h4 className="font-bold text-white text-xs">Async Gemini Dispatch</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Coroutine launched in <code className="text-purple-300">Dispatchers.IO</code> via <code className="text-purple-300">SupervisorJob</code>. UI thread remains completely unblocked for instant typing.
            </p>
          </div>

          {/* Step 4 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                PHASE 4
              </span>
              <Zap className="w-4 h-4 text-slate-500" />
            </div>
            <h4 className="font-bold text-white text-xs">InputConnection Commit</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Result is safely injected via <code className="text-emerald-300">commitText()</code> or <code className="text-emerald-300">deleteSurroundingText()</code> directly into WhatsApp, Gmail, or any field.
            </p>
          </div>
        </div>
      </div>

      {/* Feature Matrix: NIK-Ai board vs Gboard vs QuillBot Web */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Zap className="w-4 h-4 text-emerald-400" />
          Feature Matrix: NIK-Ai board vs Standard Keyboards
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono">
                <th className="py-3 px-4">Feature / Capability</th>
                <th className="py-3 px-4 text-emerald-400 font-bold">NIK-Ai board (Custom IME)</th>
                <th className="py-3 px-4">Gboard (Google)</th>
                <th className="py-3 px-4">QuillBot (Web / Ext)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2.5 px-4 font-semibold text-white">System-wide Android Keyboard (IME)</td>
                <td className="py-2.5 px-4 text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Native InputMethodService
                </td>
                <td className="py-2.5 px-4 text-slate-300">Yes</td>
                <td className="py-2.5 px-4 text-slate-500">No (Browser Ext only)</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-white">6-Mode Paraphraser (Standard, Fluency, Formal...)</td>
                <td className="py-2.5 px-4 text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Inline 1-tap Replace
                </td>
                <td className="py-2.5 px-4 text-slate-500">No (Basic Proofread only)</td>
                <td className="py-2.5 px-4 text-emerald-300">Yes (Requires app switch)</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-white">Real-Time Grammar &amp; Spell Fix</td>
                <td className="py-2.5 px-4 text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Underline spans &amp; Fix All
                </td>
                <td className="py-2.5 px-4 text-slate-300">Basic dictionary</td>
                <td className="py-2.5 px-4 text-emerald-300">Yes</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-white">30+ Languages (Malayalam, Hindi, Spanish...)</td>
                <td className="py-2.5 px-4 text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Live Gemini Translation
                </td>
                <td className="py-2.5 px-4 text-slate-300">Google Translate popup</td>
                <td className="py-2.5 px-4 text-slate-400">Limited languages</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-white">AI Content Probability Detector</td>
                <td className="py-2.5 px-4 text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Built-in Badge &amp; Score
                </td>
                <td className="py-2.5 px-4 text-slate-500">None</td>
                <td className="py-2.5 px-4 text-emerald-300">Web app only</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-white">Floating Overlay Widget (Over Gboard)</td>
                <td className="py-2.5 px-4 text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> SYSTEM_ALERT_WINDOW mode
                </td>
                <td className="py-2.5 px-4 text-slate-500">None</td>
                <td className="py-2.5 px-4 text-slate-500">None</td>
              </tr>
              <tr>
                <td className="py-2.5 px-4 font-semibold text-white">Sensitive Field Privacy Shield</td>
                <td className="py-2.5 px-4 text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> Zero-log on Password/PIN
                </td>
                <td className="py-2.5 px-4 text-slate-300">Standard incognito</td>
                <td className="py-2.5 px-4 text-slate-400">N/A</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
