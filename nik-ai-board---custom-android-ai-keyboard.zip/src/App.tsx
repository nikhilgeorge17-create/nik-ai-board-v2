import React, { useState } from 'react';
import {
  Sparkles,
  Smartphone,
  Code2,
  FileCode,
  Layers,
  Download,
  Volume2,
  VolumeX,
  Vibrate,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Github
} from 'lucide-react';
import { AndroidSimulator } from './components/AndroidSimulator';
import { ProjectCodeExplorer } from './components/ProjectCodeExplorer';
import { ArchitectureView } from './components/ArchitectureView';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'code' | 'architecture'>('simulator');
  const [keyboardTheme, setKeyboardTheme] = useState<'dark' | 'slate' | 'light'>('dark');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [hapticEnabled, setHapticEnabled] = useState<boolean>(true);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* 1. TOP HEADER & NAVIGATION */}
      <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80 px-4 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          
          {/* Logo & Product Badge */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black">
              <Sparkles className="w-5 h-5 fill-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-white text-base tracking-tight">NIK-Ai board</h1>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30 uppercase tracking-wide">
                  Android IME
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Gemini AI Active" />
              </div>
              <p className="text-[11px] text-slate-400">
                Production-Ready Android Custom Keyboard • Powered by Gemini AI
              </p>
            </div>
          </div>

          {/* Center Navigation Tabs */}
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 shadow-inner">
            <button
              type="button"
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'simulator'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Live Phone Simulator</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'code'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Android Project Source</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('architecture')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'architecture'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Architecture &amp; Specs</span>
            </button>
          </div>

          {/* Right Tactile & Theme Controls */}
          <div className="flex items-center gap-2">
            {/* Audio Toggle */}
            <button
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2 rounded-lg border text-xs transition-all ${
                soundEnabled
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
              title={soundEnabled ? 'Key sound enabled' : 'Key sound muted'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Haptic Toggle */}
            <button
              type="button"
              onClick={() => setHapticEnabled(!hapticEnabled)}
              className={`p-2 rounded-lg border text-xs transition-all ${
                hapticEnabled
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
              title={hapticEnabled ? 'Haptic feedback on' : 'Haptic feedback off'}
            >
              <Vibrate className="w-4 h-4" />
            </button>

            {/* Theme Dropdown */}
            <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-800 text-xs">
              {(['dark', 'slate', 'light'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setKeyboardTheme(t)}
                  className={`px-2 py-1 rounded text-[11px] capitalize font-semibold transition-all ${
                    keyboardTheme === t
                      ? 'bg-emerald-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* 2. MAIN BODY CONTENT */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 md:p-6 flex flex-col justify-center">
        {activeTab === 'simulator' && (
          <AndroidSimulator
            theme={keyboardTheme}
            soundEnabled={soundEnabled}
            hapticEnabled={hapticEnabled}
            onThemeChange={setKeyboardTheme}
            onSoundToggle={setSoundEnabled}
            onHapticToggle={setHapticEnabled}
          />
        )}

        {activeTab === 'code' && (
          <ProjectCodeExplorer />
        )}

        {activeTab === 'architecture' && (
          <ArchitectureView />
        )}
      </main>

      {/* 3. FOOTER */}
      <footer className="w-full bg-slate-950 border-t border-slate-800/80 py-4 px-6 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">NIK-Ai board</span>
            <span>•</span>
            <span>InputMethodService registered with <code className="text-emerald-400">android.permission.BIND_INPUT_METHOD</code></span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" /> Zero-blocking async coroutines
            </span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" /> Sensitive Field Guard
            </span>
            <span>Jetpack Compose UI</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
