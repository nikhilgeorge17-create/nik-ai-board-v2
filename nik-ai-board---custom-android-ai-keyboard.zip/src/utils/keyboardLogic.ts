/**
 * Pure business logic and Android InputConnection simulation utilities
 * for NIK-Ai board custom keyboard.
 */

export interface InputState {
  text: string;
  selectionStart: number;
  selectionEnd: number;
}

export interface GrammarError {
  original: string;
  suggestion: string;
  reason: string;
  offset: number;
  length: number;
}

/**
 * Simulates Android InputConnection.commitText(CharSequence text, int newCursorPosition)
 */
export function commitText(
  state: InputState,
  insertedText: string
): InputState {
  const { text, selectionStart, selectionEnd } = state;
  const start = Math.min(selectionStart, selectionEnd);
  const end = Math.max(selectionStart, selectionEnd);

  const newText = text.substring(0, start) + insertedText + text.substring(end);
  const newPos = start + insertedText.length;

  return {
    text: newText,
    selectionStart: newPos,
    selectionEnd: newPos,
  };
}

/**
 * Simulates Android InputConnection.deleteSurroundingText(int beforeLength, int afterLength)
 */
export function deleteSurroundingText(
  state: InputState,
  beforeLength: number = 1,
  afterLength: number = 0
): InputState {
  const { text, selectionStart, selectionEnd } = state;

  // If there's an active selection, backspace deletes the selection
  if (selectionStart !== selectionEnd) {
    const start = Math.min(selectionStart, selectionEnd);
    const end = Math.max(selectionStart, selectionEnd);
    const newText = text.substring(0, start) + text.substring(end);
    return {
      text: newText,
      selectionStart: start,
      selectionEnd: start,
    };
  }

  // Otherwise delete beforeLength characters before cursor
  const deleteCount = Math.min(beforeLength, selectionStart);
  const start = selectionStart - deleteCount;
  const end = Math.min(text.length, selectionEnd + afterLength);

  const newText = text.substring(0, start) + text.substring(end);
  return {
    text: newText,
    selectionStart: start,
    selectionEnd: start,
  };
}

/**
 * Extracts current word surrounding cursor position
 */
export function getCurrentWordAtCursor(text: string, cursor: number): { word: string; start: number; end: number } {
  if (!text || cursor < 0) return { word: '', start: 0, end: 0 };
  const safeCursor = Math.min(cursor, text.length);

  // Search left
  let start = safeCursor;
  while (start > 0 && /\w/.test(text.charAt(start - 1))) {
    start--;
  }

  // Search right
  let end = safeCursor;
  while (end < text.length && /\w/.test(text.charAt(end))) {
    end++;
  }

  return {
    word: text.substring(start, end),
    start,
    end,
  };
}

/**
 * Safeguards sensitive user data (passwords, OTPs, credit cards)
 * Prevents telemetry and unauthorized cloud AI transmission of secret fields.
 */
export function isSensitiveInput(fieldName: string = '', inputType: string = '', value: string = ''): boolean {
  const lowerField = fieldName.toLowerCase();
  const lowerType = inputType.toLowerCase();

  // Field names indicating sensitive data
  const sensitiveFieldPatterns = [
    'password',
    'passcode',
    'secret',
    'pin',
    'otp',
    'cvv',
    'cvc',
    'ssn',
    'credit',
    'cardnumber',
    'auth_token',
  ];

  if (sensitiveFieldPatterns.some(p => lowerField.includes(p))) {
    return true;
  }

  // Android InputType flags (e.g., TYPE_TEXT_VARIATION_PASSWORD = 129)
  if (lowerType.includes('password') || lowerType.includes('pin') || lowerType.includes('hidden')) {
    return true;
  }

  // Value patterns: 4-6 digit standalone OTP or 16-digit credit card pattern
  if (/^\b\d{4,6}\b$/.test(value.trim()) && lowerField.includes('code')) {
    return true;
  }
  if (/^\b(?:\d{4}[ -]?){3}\d{4}\b$/.test(value.trim())) {
    return true;
  }

  return false;
}

/**
 * Filters synonyms based on vocabulary density setting (1 to 5)
 */
export function filterSynonymsByDensity(
  suggestions: Array<{ word: string; synonyms: string[] }>,
  density: number
): Array<{ word: string; synonyms: string[] }> {
  const clamped = Math.max(1, Math.min(5, density));
  // At density 1, only show 1 synonym per word and limit total words
  // At density 5, show all synonyms for all detected words
  const maxWords = Math.ceil((clamped / 5) * suggestions.length);
  return suggestions.slice(0, maxWords).map(item => ({
    word: item.word,
    synonyms: item.synonyms.slice(0, clamped <= 2 ? 1 : clamped <= 4 ? 2 : 4),
  }));
}

/**
 * Computes heuristic metrics for text (word count, reading time, character count)
 */
export function getTextMetrics(text: string) {
  const trimmed = text.trim();
  const words = trimmed ? trimmed.split(/\s+/).length : 0;
  const chars = text.length;
  const readingTimeSec = Math.ceil((words / 200) * 60);

  return {
    words,
    chars,
    readingTimeSec,
  };
}
