import test from 'node:test';
import assert from 'node:assert/strict';
import {
  commitText,
  deleteSurroundingText,
  getCurrentWordAtCursor,
  isSensitiveInput,
  filterSynonymsByDensity,
  getTextMetrics,
} from './keyboardLogic';

test('commitText inserts text at cursor position in empty state', () => {
  const initial = { text: '', selectionStart: 0, selectionEnd: 0 };
  const result = commitText(initial, 'Hello');
  assert.equal(result.text, 'Hello');
  assert.equal(result.selectionStart, 5);
  assert.equal(result.selectionEnd, 5);
});

test('commitText inserts in the middle of existing text', () => {
  const initial = { text: 'Helld', selectionStart: 4, selectionEnd: 4 };
  const result = commitText(initial, 'o worl');
  assert.equal(result.text, 'Hello world');
  assert.equal(result.selectionStart, 10);
});

test('commitText replaces selected text when selection range exists', () => {
  const initial = { text: 'I am sad today', selectionStart: 5, selectionEnd: 8 };
  const result = commitText(initial, 'happy');
  assert.equal(result.text, 'I am happy today');
  assert.equal(result.selectionStart, 10);
  assert.equal(result.selectionEnd, 10);
});

test('deleteSurroundingText deletes 1 char before cursor (backspace)', () => {
  const initial = { text: 'Hello', selectionStart: 5, selectionEnd: 5 };
  const result = deleteSurroundingText(initial, 1, 0);
  assert.equal(result.text, 'Hell');
  assert.equal(result.selectionStart, 4);
});

test('deleteSurroundingText removes active selection without extra char deletion', () => {
  const initial = { text: 'Hello World', selectionStart: 6, selectionEnd: 11 };
  const result = deleteSurroundingText(initial, 1, 0);
  assert.equal(result.text, 'Hello ');
  assert.equal(result.selectionStart, 6);
  assert.equal(result.selectionEnd, 6);
});

test('getCurrentWordAtCursor accurately detects surrounding word boundaries', () => {
  const text = 'Quick brown fox jumps';
  // Cursor in 'brown' (index 8)
  const result = getCurrentWordAtCursor(text, 8);
  assert.equal(result.word, 'brown');
  assert.equal(result.start, 6);
  assert.equal(result.end, 11);
});

test('isSensitiveInput flags password, PIN, OTP, and credit card fields', () => {
  assert.equal(isSensitiveInput('user_password', 'text'), true);
  assert.equal(isSensitiveInput('security_pin', 'number'), true);
  assert.equal(isSensitiveInput('otp_input', 'text'), true);
  assert.equal(isSensitiveInput('normal_chat', 'text', '1234-5678-9012-3456'), true);
  assert.equal(isSensitiveInput('email_body', 'text', 'Hello, this is regular text'), false);
});

test('filterSynonymsByDensity scales appropriately with density setting', () => {
  const suggestions = [
    { word: 'smart', synonyms: ['intelligent', 'clever', 'brilliant', 'astute'] },
    { word: 'fast', synonyms: ['quick', 'rapid', 'swift', 'speedy'] },
    { word: 'good', synonyms: ['great', 'fine', 'stellar', 'superb'] },
  ];

  const lowDensity = filterSynonymsByDensity(suggestions, 1);
  assert.equal(lowDensity.length, 1);
  assert.equal(lowDensity[0].synonyms.length, 1);

  const highDensity = filterSynonymsByDensity(suggestions, 5);
  assert.equal(highDensity.length, 3);
  assert.equal(highDensity[0].synonyms.length, 4);
});

test('getTextMetrics correctly counts words and calculates reading time', () => {
  const metrics = getTextMetrics('The quick brown fox jumps over the lazy dog');
  assert.equal(metrics.words, 9);
  assert.equal(metrics.chars, 43);
  assert.ok(metrics.readingTimeSec >= 1);
});
